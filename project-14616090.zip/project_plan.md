# CySEC - Cyprus Securities and Exchange Commission

## 1. Project Description
Official website for the Cyprus Securities and Exchange Commission (CySEC / КЦКБ), a financial market regulator overseeing the supervision and regulation of investment services, securities markets, and related entities in Cyprus. The site serves investors, licensed entities, and the general public with regulatory information, warnings, news, and online services.

**Target users:** Investors, financial professionals, licensed entities, legal professionals, media, and general public.
**Core value:** Provide transparent, authoritative regulatory information and investor protection tools.

## 2. Page Structure
- `/` - Home (hero, quick access, news, warnings, education hub, media)
- `/about` - About the Regulator (mission, history, leadership, structure)
- `/news` - News and Announcements
- `/warnings` - Investor Warnings (unauthorized entities, scam alerts)
- `/registry` - Licensed Entities Registry (searchable register of licensed firms)
- `/complaint` - Submit a Complaint (form)
- `/legislation` - Legislation and Regulatory Framework
- `/contact` - Contact Us (address, phone, email, map)
- `*` - Not Found

## 3. Core Features
- [ ] Bilingual support (Bulgarian / English) with language switcher
- [ ] Rich homepage with hero banner, quick access icons, news feed, warnings, education hub
- [ ] About page with mission, history, leadership
- [ ] Investor warnings listing with search/filter
- [ ] Licensed entities registry with search and filtering
- [ ] Complaint submission form (integrated via Form tool)
- [ ] Legislation page with categorized regulatory documents
- [ ] Contact page with address, phone, email, and Google Maps embed
- [ ] Responsive design (desktop-first with mobile fallback)
- [ ] SEO-optimized metadata and semantic markup

## 4. Data Model Design
No database required. This is a content-driven informational website. All data served via:
- Static i18n translation files for bilingual content
- Mock data files for licensed entities, warnings, news, legislation
- Form submission for complaints handled via built-in Form tool

## 5. Backend / Third-party Integration Plan
- Database: Not needed — all data is static/demonstration content
- Shopify: Not needed
- Stripe: Not needed
- Form: Complaint form via get_form_url (built-in form submission)
- Maps: Google Maps embed iframe for contact page location
- No authentication or payment systems required

## 6. Development Phase Plan

### Phase 1: Foundation + Home Page
- Goal: Set up i18n (BG/EN), Tailwind theme, shared Navbar and Footer, and build the complete rich homepage
- Deliverable: Working homepage with hero, quick access icons, latest updates, news feed, investor warnings preview, education hub, and footer — fully bilingual and responsive

### Phase 2: About, Warnings, Registry
- Goal: Build the About page, Investor Warnings listing page, and Licensed Entities Registry with search
- Deliverable: Three functional pages with rich content and demo data

### Phase 3: Complaint, Legislation, Documents, Contact
- Goal: Build the complaint form, legislation page, documents page with categorized forms/laws/guides, and contact page with map
- Deliverable: Complete pages finishing the site
- Status: Documents page done, Complaint page done, Legislation page done

### Phase 4: Polish & Final Review
- Goal: Final responsiveness checks, SEO meta tags, performance review, and cross-language validation
- Deliverable: Production-ready site