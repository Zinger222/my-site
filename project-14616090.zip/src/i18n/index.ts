import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import messages from './local/index';

const getInitialLanguage = (): string => {
  const browser =
    (typeof navigator !== 'undefined' ? navigator.language || '' : '').slice(0, 2).toLowerCase();
  if (browser === 'it') return 'it';
  if (browser === 'bg') return 'bg';
  return 'en';
};

i18n
  .use(initReactI18next)
  .init({
    lng: getInitialLanguage(),
    fallbackLng: 'bg',
    debug: false,
    resources: messages,
    interpolation: {
      escapeValue: false,
    },
  });

export default i18n;