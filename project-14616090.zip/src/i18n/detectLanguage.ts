import i18n from './index';

export type SupportedLang = 'bg' | 'it' | 'en';

const STORAGE_KEY = 'cysec_user_lang';

const isSupportedLang = (value: string | null): value is SupportedLang =>
  value === 'bg' || value === 'it' || value === 'en';

// Map an ISO country code to one of the supported languages.
// Bulgaria -> Bulgarian, Italy -> Italian, everything else -> English.
const mapCountryToLang = (countryCode?: string): SupportedLang => {
  const code = (countryCode || '').trim().toUpperCase();
  if (code === 'BG') return 'bg';
  if (code === 'IT') return 'it';
  return 'en';
};

const getBrowserLang = (): SupportedLang => {
  const browser = (typeof navigator !== 'undefined' ? navigator.language || '' : '')
    .slice(0, 2)
    .toLowerCase();
  if (browser === 'bg') return 'bg';
  if (browser === 'it') return 'it';
  return 'en';
};

// Remember a language the user explicitly picked, so IP detection never overrides it.
export const getUserLanguage = (): SupportedLang | null => {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    return isSupportedLang(stored) ? stored : null;
  } catch {
    return null;
  }
};

export const setUserLanguage = (lang: SupportedLang): void => {
  try {
    localStorage.setItem(STORAGE_KEY, lang);
  } catch {
    // ignore storage access errors
  }
  i18n.changeLanguage(lang);
};

const applyLanguage = async (lang: SupportedLang): Promise<void> => {
  if (i18n.language !== lang) {
    await i18n.changeLanguage(lang);
  }
};

// Detect the visitor's language from their IP location (BG / IT / everything else -> EN).
export const detectLanguageByIp = async (): Promise<void> => {
  const stored = getUserLanguage();
  if (stored) {
    await applyLanguage(stored);
    return;
  }

  try {
    const res = await fetch('https://ipwho.is/', { headers: { Accept: 'application/json' } });
    if (!res.ok) throw new Error('ip lookup failed');
    const data = await res.json();
    if (data && data.success === false) throw new Error('ip lookup unsuccessful');
    await applyLanguage(mapCountryToLang(data?.country_code));
  } catch {
    await applyLanguage(getBrowserLang());
  }
};