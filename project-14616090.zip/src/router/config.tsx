import type { RouteObject } from "react-router-dom";
import NotFound from "../pages/NotFound";
import Home from "../pages/home/page";
import BrokerCheck from "../pages/broker-check/page";
import AboutPage from "../pages/about/page";
import LegislationPage from "../pages/legislation/page";
import WarningsPage from "../pages/warnings/page";
import ComplaintPage from "../pages/complaint/page";
import DocumentsPage from "../pages/documents/page";

const routes: RouteObject[] = [
  {
    path: "/",
    element: <Home />,
  },
  {
    path: "/broker-check",
    element: <BrokerCheck />,
  },
  {
    path: "/about",
    element: <AboutPage />,
  },
  {
    path: "/legislation",
    element: <LegislationPage />,
  },
  {
    path: "/warnings",
    element: <WarningsPage />,
  },
  {
    path: "/complaint",
    element: <ComplaintPage />,
  },
  {
    path: "/documents",
    element: <DocumentsPage />,
  },
  {
    path: "*",
    element: <NotFound />,
  },
];

export default routes;