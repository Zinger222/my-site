import { StrictMode } from 'react'
import './i18n'
import { detectLanguageByIp } from './i18n/detectLanguage'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.tsx'

detectLanguageByIp();

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
)