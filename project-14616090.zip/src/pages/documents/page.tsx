import { useTranslation } from 'react-i18next';
import { documentCategories } from '@/mocks/documents';

export default function DocumentsPage() {
  const { t } = useTranslation('common');

  return (
    <div className="min-h-screen bg-background-50">
      {/* Header */}
      <section className="relative h-[280px] md:h-[360px] w-full overflow-hidden flex items-center">
        <div className="absolute inset-0">
          <img
            src="https://readdy.ai/api/search-image?query=Organized%20legal%20documents%20and%20folders%20on%20a%20clean%20modern%20desk%2C%20stack%20of%20paper%20files%20with%20paperclips%20and%20pens%2C%20warm%20neutral%20lighting%2C%20professional%20archive%20and%20documentation%20concept%2C%20editorial%20photography%20style%2C%20soft%20shadows%2C%20no%20people&width=1600&height=900&seq=documents-hero&orientation=landscape"
            alt="Documents"
            className="w-full h-full object-cover"
          />
        </div>
        <div className="absolute inset-0 bg-background-950/70" />
        <div className="relative z-10 w-full px-4 md:px-8 lg:px-12">
          <div className="max-w-4xl">
            <h1 className="text-2xl md:text-4xl font-heading font-bold text-white leading-tight mb-3">
              {t('documents_title')}
            </h1>
            <p className="text-base text-foreground-200 max-w-2xl leading-relaxed">
              {t('documents_subtitle')}
            </p>
          </div>
        </div>
      </section>

      {/* Content */}
      <div className="w-full px-4 md:px-8 lg:px-12 py-10 md:py-16">
        <div className="max-w-5xl mx-auto space-y-8 md:space-y-12">
          {documentCategories.map((cat) => (
            <div key={cat.id}>
              {/* Category header */}
              <div className="flex items-center gap-3 mb-4 md:mb-6">
                <div className="w-10 h-10 md:w-12 md:h-12 flex items-center justify-center rounded-lg bg-primary-100 text-primary-700 shrink-0">
                  <i className={`${cat.icon} text-lg md:text-xl`} />
                </div>
                <div>
                  <h2 className="text-lg md:text-xl font-heading font-semibold text-foreground-900">
                    {t(cat.titleKey)}
                  </h2>
                  <p className="text-xs md:text-sm text-foreground-600">
                    {t(cat.descKey)}
                  </p>
                </div>
              </div>

              {/* Documents list */}
              <div className="space-y-3">
                {cat.items.map((doc, idx) => (
                  <a
                    key={idx}
                    href={doc.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="group flex items-center gap-3 md:gap-4 p-4 md:p-5 rounded-lg bg-background-100 border border-background-200/70 hover:border-primary-300 hover:bg-background-200/50 transition-all"
                  >
                    <div className="w-10 h-10 md:w-12 md:h-12 flex items-center justify-center rounded-md bg-accent-100 text-accent-700 shrink-0">
                      <i className="ri-file-text-line text-lg md:text-xl" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm md:text-base font-medium text-foreground-900 group-hover:text-primary-700 transition-colors leading-snug mb-0.5">
                        {t(doc.nameKey)}
                      </div>
                      <div className="text-xs text-foreground-500 flex items-center gap-2">
                        <span>{doc.file}</span>
                        <span className="hidden sm:inline text-foreground-300">|</span>
                        <span className="hidden sm:inline">{doc.size}</span>
                      </div>
                    </div>
                    <div className="shrink-0 w-9 h-9 flex items-center justify-center rounded-md bg-background-200 text-foreground-500 group-hover:bg-primary-600 group-hover:text-white transition-all">
                      <i className="ri-download-2-line text-lg" />
                    </div>
                  </a>
                ))}
              </div>
            </div>
          ))}

          {/* Note */}
          <div className="p-5 md:p-6 rounded-lg bg-accent-50 border border-accent-200/70">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 flex items-center justify-center rounded-md bg-accent-100 text-accent-700 shrink-0">
                <i className="ri-information-line text-sm" />
              </div>
              <p className="text-sm text-accent-800 leading-relaxed">
                {t('documents_note')}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}