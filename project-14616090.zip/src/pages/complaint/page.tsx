import { useState, useRef, FormEvent } from 'react';
import { useTranslation } from 'react-i18next';

export default function ComplaintPage() {
  const { t } = useTranslation('common');
  const [status, setStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const formRef = useRef<HTMLFormElement>(null);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setStatus('success');
    if (formRef.current) {
      formRef.current.reset();
    }
  };

  return (
    <div className="min-h-screen bg-background-50">
      {/* Header */}
      <section className="relative h-[280px] md:h-[360px] w-full overflow-hidden flex items-center">
        <div className="absolute inset-0">
          <img
            src="https://readdy.ai/api/search-image?query=Professional%20customer%20service%20support%20desk%20in%20modern%20office%2C%20headset%20and%20documents%20on%20clean%20desk%2C%20warm%20neutral%20lighting%2C%20corporate%20help%20center%20concept%2C%20editorial%20photography%20style%2C%20soft%20focus%20background%2C%20no%20people%20visible&width=1600&height=900&seq=complaint-hero&orientation=landscape"
            alt="Complaint Form"
            className="w-full h-full object-cover"
          />
        </div>
        <div className="absolute inset-0 bg-background-950/70" />
        <div className="relative z-10 w-full px-4 md:px-8 lg:px-12">
          <div className="max-w-4xl">
            <h1 className="text-2xl md:text-4xl font-heading font-bold text-white leading-tight mb-3">
              {t('complaint_title')}
            </h1>
            <p className="text-base text-foreground-200 max-w-2xl leading-relaxed">
              {t('complaint_subtitle')}
            </p>
          </div>
        </div>
      </section>

      {/* Content */}
      <div className="w-full px-4 md:px-8 lg:px-12 py-10 md:py-16">
        <div className="max-w-5xl mx-auto grid grid-cols-1 lg:grid-cols-5 gap-8 lg:gap-12">
          {/* Left: Info */}
          <div className="lg:col-span-2 space-y-6">
            <div className="p-5 rounded-lg bg-background-100 border border-background-200/70">
              <h3 className="text-sm font-semibold text-foreground-900 mb-3 flex items-center gap-2">
                <i className="ri-information-line text-primary-600" />
                {t('complaint_info_title')}
              </h3>
              <p className="text-sm text-foreground-600 leading-relaxed mb-4">
                {t('complaint_info_text')}
              </p>
              <a
                href="https://www.cysec.gov.cy/en-GB/investor-protection/how-to-complain/"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 text-sm font-medium text-primary-600 hover:text-primary-700 transition-colors"
              >
                {t('learn_more')}
                <i className="ri-arrow-right-line" />
              </a>
            </div>

            <div className="p-5 rounded-lg bg-accent-50 border border-accent-200/70">
              <h3 className="text-sm font-semibold text-accent-900 mb-3 flex items-center gap-2">
                <i className="ri-file-list-3-line text-accent-700" />
                {t('complaint_docs_title')}
              </h3>
              <ul className="space-y-2">
                <li className="flex items-start gap-2 text-sm text-accent-700">
                  <i className="ri-check-line text-accent-600 mt-0.5 shrink-0" />
                  <span>{t('complaint_doc_1')}</span>
                </li>
                <li className="flex items-start gap-2 text-sm text-accent-700">
                  <i className="ri-check-line text-accent-600 mt-0.5 shrink-0" />
                  <span>{t('complaint_doc_2')}</span>
                </li>
                <li className="flex items-start gap-2 text-sm text-accent-700">
                  <i className="ri-check-line text-accent-600 mt-0.5 shrink-0" />
                  <span>{t('complaint_doc_3')}</span>
                </li>
              </ul>
            </div>

            <div className="p-5 rounded-lg bg-primary-50 border border-primary-200/70">
              <h3 className="text-sm font-semibold text-primary-900 mb-2">
                {t('financial_ombudsman')}
              </h3>
              <p className="text-sm text-primary-700 leading-relaxed mb-3">
                {t('financial_ombudsman_text')}
              </p>
              <a
                href="https://www.cysec.gov.cy/en-GB/investor-protection/fin-ombud/"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 text-sm font-medium text-primary-600 hover:text-primary-700 transition-colors"
              >
                {t('learn_more')}
                <i className="ri-arrow-right-line" />
              </a>
            </div>
          </div>

          {/* Right: Form */}
          <div className="lg:col-span-3">
            <div className="p-5 md:p-6 rounded-lg bg-background-100 border border-background-200/70">
              <h2 className="text-lg font-heading font-semibold text-foreground-900 mb-4">
                {t('complaint_form_title')}
              </h2>

              {status === 'success' && (
                <div className="mb-4 p-4 rounded-md bg-green-50 border border-green-200 text-sm text-green-800">
                  <div className="flex items-center gap-2 mb-1">
                    <i className="ri-checkbox-circle-line text-green-600" />
                    <span className="font-semibold">{t('complaint_success')}</span>
                  </div>
                  <p className="text-green-700">{t('complaint_success_desc')}</p>
                </div>
              )}

              {status === 'error' && (
                <div className="mb-4 p-4 rounded-md bg-red-50 border border-red-200 text-sm text-red-800">
                  <div className="flex items-center gap-2 mb-1">
                    <i className="ri-error-warning-line text-red-600" />
                    <span className="font-semibold">{t('complaint_error')}</span>
                  </div>
                  <p className="text-red-700">{t('complaint_error_desc')}</p>
                </div>
              )}

              <form ref={formRef} onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-foreground-700 mb-1">
                      {t('first_name')}
                    </label>
                    <input
                      type="text"
                      name="first_name"
                      required
                      className="w-full px-3 py-2.5 rounded-md border border-background-300 bg-background-50 text-sm text-foreground-800 focus:outline-none focus:border-primary-400 focus:ring-1 focus:ring-primary-400"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-foreground-700 mb-1">
                      {t('last_name')}
                    </label>
                    <input
                      type="text"
                      name="last_name"
                      required
                      className="w-full px-3 py-2.5 rounded-md border border-background-300 bg-background-50 text-sm text-foreground-800 focus:outline-none focus:border-primary-400 focus:ring-1 focus:ring-primary-400"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground-700 mb-1">
                    {t('email')}
                  </label>
                  <input
                    type="email"
                    name="email"
                    required
                    className="w-full px-3 py-2.5 rounded-md border border-background-300 bg-background-50 text-sm text-foreground-800 focus:outline-none focus:border-primary-400 focus:ring-1 focus:ring-primary-400"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground-700 mb-1">
                    {t('complaint_entity')}
                  </label>
                  <input
                    type="text"
                    name="entity"
                    required
                    placeholder={t('complaint_entity_placeholder')}
                    className="w-full px-3 py-2.5 rounded-md border border-background-300 bg-background-50 text-sm text-foreground-800 focus:outline-none focus:border-primary-400 focus:ring-1 focus:ring-primary-400"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground-700 mb-1">
                    {t('complaint_ref')}
                  </label>
                  <input
                    type="text"
                    name="reference"
                    placeholder={t('complaint_ref_placeholder')}
                    className="w-full px-3 py-2.5 rounded-md border border-background-300 bg-background-50 text-sm text-foreground-800 focus:outline-none focus:border-primary-400 focus:ring-1 focus:ring-primary-400"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground-700 mb-1">
                    {t('complaint_details')}
                  </label>
                  <textarea
                    name="details"
                    rows={5}
                    required
                    maxLength={500}
                    placeholder={t('complaint_details_placeholder')}
                    className="w-full px-3 py-2.5 rounded-md border border-background-300 bg-background-50 text-sm text-foreground-800 focus:outline-none focus:border-primary-400 focus:ring-1 focus:ring-primary-400 resize-none"
                  />
                  <div className="text-xs text-foreground-500 mt-1">
                    {t('max_chars')}
                  </div>
                </div>

                {/* Honeypot */}
                <input
                  type="text"
                  name="website_alt"
                  tabIndex={-1}
                  autoComplete="off"
                  aria-hidden="true"
                  readOnly
                  className="opacity-0 absolute w-0 h-0"
                />

                <button
                  type="submit"
                  className="w-full px-6 py-3 bg-primary-600 hover:bg-primary-700 text-white rounded-md font-medium text-sm transition-all"
                >
                  {t('submit_complaint')}
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}