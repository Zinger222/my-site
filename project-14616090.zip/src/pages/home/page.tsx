import HeroSection from './components/HeroSection';
import BrokerCheckBanner from './components/BrokerCheckBanner';
import QuickAccess from './components/QuickAccess';
import ContentGrid from './components/ContentGrid';
import NewsMedia from './components/NewsMedia';
import EducationHub from './components/EducationHub';
import InvestorWarnings from './components/InvestorWarnings';

export default function HomePage() {
  return (
    <div className="flex flex-col min-h-screen">
      <HeroSection />
      <BrokerCheckBanner />
      <QuickAccess />
      <ContentGrid />
      <InvestorWarnings />
      <NewsMedia />
      <EducationHub />
    </div>
  );
}