import { useTranslation } from 'react-i18next';

export default function NewsMedia() {
  const { t } = useTranslation('common');

  return (
    <section className="relative h-[320px] md:h-[400px] w-full overflow-hidden flex items-center justify-center">
      {/* Background image */}
      <div className="absolute inset-0">
        <img
          src="https://readdy.ai/api/search-image?query=Abstract%20dark%20financial%20technology%20background%2C%20glowing%20network%20lines%20and%20data%20nodes%20in%20deep%20teal%20and%20emerald%20green%20tones%2C%20modern%20corporate%20aesthetic%2C%20subtle%20geometric%20grid%20pattern%2C%20moody%20atmospheric%20lighting%2C%20no%20text%20no%20people&width=1600&height=900&seq=newsmedia-bg&orientation=landscape"
          alt="News and media background"
          className="w-full h-full object-cover"
        />
      </div>

      {/* Dark overlay */}
      <div className="absolute inset-0 bg-background-950/75" />

      {/* Content */}
      <div className="relative z-10 text-center px-4 md:px-8">
        <h2 className="text-xl md:text-3xl font-heading font-bold text-white mb-3 md:mb-4">
          {t('news_media')}
        </h2>
        <p className="text-sm md:text-base text-foreground-300 max-w-2xl mx-auto mb-6 md:mb-8 leading-relaxed">
          {t('news_media_desc')}
        </p>
        <a
          href="https://www.cysec.gov.cy/en-GB/cysec/about-us/public-presence/"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-2 px-6 py-3 bg-primary-600 hover:bg-primary-700 text-white rounded-md font-medium text-sm transition-all whitespace-nowrap"
        >
          {t('news_media_cta')}
          <i className="ri-arrow-right-line" />
        </a>
      </div>
    </section>
  );
}