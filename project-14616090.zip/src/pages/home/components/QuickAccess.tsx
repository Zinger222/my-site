import { useTranslation } from 'react-i18next';
import { Link } from 'react-router-dom';

const quickItems = [
  { key: 'quick_broker_check', icon: 'ri-user-search-line', href: '/broker-check', external: false },
  { key: 'quick_certifications', icon: 'ri-award-line', href: 'https://www.cysec.gov.cy/en-GB/public-info/certifications-and-seminars/', external: true },
  { key: 'quick_recruitment', icon: 'ri-user-add-line', href: 'https://www.cysec.gov.cy/en-GB/cysec/about-us/recruitment/', external: true },
  { key: 'quick_warnings', icon: 'ri-alarm-warning-line', href: '/warnings', external: false },
  { key: 'quick_compensation', icon: 'ri-shield-check-line', href: 'https://www.cysec.gov.cy/en-GB/investor-protection/tae/', external: true },
  { key: 'quick_domains', icon: 'ri-earth-line', href: 'https://www.cysec.gov.cy/entities/investment-firms/approved-domains/', external: true },
  { key: 'quick_complaint', icon: 'ri-file-list-3-line', href: '/complaint', external: false },
];

export default function QuickAccess() {
  const { t } = useTranslation('common');

  return (
    <section id="quick-access" className="bg-background-950 py-0">
      <div className="w-full px-4 md:px-8 lg:px-12">
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-7 divide-x divide-y divide-foreground-800/20">
          {quickItems.map((item) => {
            const content = (
              <div className="group flex flex-col items-center justify-center py-6 md:py-8 px-3 hover:bg-foreground-800/10 transition-all cursor-pointer">
                <div className="w-10 h-10 md:w-12 md:h-12 flex items-center justify-center mb-2 md:mb-3">
                  <i className={`${item.icon} text-xl md:text-2xl text-accent-500 group-hover:text-accent-400 transition-colors`} />
                </div>
                <span className="text-xs md:text-sm text-center text-foreground-300 font-medium leading-tight group-hover:text-white transition-colors">
                  {t(item.key)}
                </span>
              </div>
            );

            if (item.external) {
              return (
                <a
                  key={item.key}
                  href={item.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block"
                >
                  {content}
                </a>
              );
            }

            return (
              <Link
                key={item.key}
                to={item.href}
                className="block"
              >
                {content}
              </Link>
            );
          })}
        </div>
      </div>
    </section>
  );
}