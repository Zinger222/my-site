import { useTranslation } from 'react-i18next';

const eduItems = [
  { key: 'edu_featured', icon: 'ri-article-line', url: 'https://www.cysec.gov.cy/en-GB/investor-protection/financial-education/' },
  { key: 'edu_news', icon: 'ri-newspaper-line', url: 'https://www.cysec.gov.cy/en-GB/public-info/' },
  { key: 'edu_scams', icon: 'ri-alarm-warning-line', url: 'https://www.cysec.gov.cy/en-GB/investor-protection/financial-education/' },
  { key: 'edu_literacy', icon: 'ri-book-open-line', url: 'https://www.cysec.gov.cy/en-GB/investor-protection/financial-education/' },
  { key: 'edu_questions', icon: 'ri-questionnaire-line', url: 'https://www.cysec.gov.cy/en-GB/investor-protection/financial-education/' },
  { key: 'edu_sounds', icon: 'ri-error-warning-line', url: 'https://www.cysec.gov.cy/en-GB/investor-protection/warnings/' },
  { key: 'edu_quiz', icon: 'ri-question-line', url: 'https://www.cysec.gov.cy/en-GB/investor-protection/financial-education/' },
  { key: 'edu_resilience', icon: 'ri-heart-pulse-line', url: 'https://www.cysec.gov.cy/en-GB/legislation/resilience/' },
];

export default function EducationHub() {
  const { t } = useTranslation('common');

  return (
    <section className="py-12 md:py-20 bg-background-100">
      <div className="w-full px-4 md:px-8 lg:px-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-center">
          {/* Left: Image */}
          <div className="relative rounded-lg overflow-hidden aspect-[4/3] lg:aspect-auto lg:h-[480px]">
            <img
              src="https://readdy.ai/api/search-image?query=Professional%20financial%20education%20workspace%20with%20diverse%20young%20professionals%20collaborating%20around%20laptop%20and%20documents%2C%20modern%20bright%20office%20with%20large%20windows%2C%20natural%20light%2C%20warm%20neutral%20tones%2C%20clean%20editorial%20photography%20style%2C%20professional%20corporate%20atmosphere%2C%20soft%20shadows&width=800&height=600&seq=edu-hub&orientation=landscape"
              alt="Financial education"
              className="w-full h-full object-cover"
            />
          </div>

          {/* Right: Content */}
          <div>
            <h2 className="text-xl md:text-2xl font-heading font-semibold text-foreground-900 mb-4">
              {t('education_hub')}
            </h2>
            <p className="text-sm md:text-base text-foreground-600 leading-relaxed mb-6 md:mb-8">
              {t('education_desc')}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {eduItems.map((item) => (
                <a
                  key={item.key}
                  href={item.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group flex items-center gap-3 p-3 rounded-md bg-background-50 hover:bg-primary-50 border border-transparent hover:border-primary-200 transition-all"
                >
                  <div className="w-8 h-8 flex items-center justify-center rounded-md bg-primary-100 text-primary-700 group-hover:bg-primary-600 group-hover:text-white transition-all shrink-0">
                    <i className={`${item.icon} text-sm`} />
                  </div>
                  <span className="text-sm font-medium text-foreground-700 group-hover:text-primary-700 transition-colors">
                    {t(item.key)}
                  </span>
                </a>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}