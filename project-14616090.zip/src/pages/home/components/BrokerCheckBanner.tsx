import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';

export default function BrokerCheckBanner() {
  const { t } = useTranslation('common');
  const navigate = useNavigate();
  const [query, setQuery] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      navigate(`/broker-check?search=${encodeURIComponent(query.trim())}`);
    } else {
      navigate('/broker-check');
    }
  };

  return (
    <section className="bg-background-50 py-10 md:py-14">
      <div className="w-full px-4 md:px-8 lg:px-12">
        <div className="max-w-4xl mx-auto rounded-xl border border-background-200 bg-background-50 p-6 md:p-8">
          <div className="flex flex-col md:flex-row md:items-center gap-4 md:gap-6">
            <div className="flex items-center gap-4 md:w-72 shrink-0">
              <div className="w-12 h-12 rounded-lg bg-primary-100 flex items-center justify-center shrink-0">
                <i className="ri-user-search-line text-2xl text-primary-700" />
              </div>
              <div>
                <h3 className="text-base font-heading font-semibold text-foreground-900">
                  {t('broker_check_title')}
                </h3>
                <p className="text-xs text-foreground-500 hidden md:block">
                  {t('broker_check_desc')}
                </p>
              </div>
            </div>
            <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row flex-1 gap-3">
              <div className="relative flex-grow">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <i className="ri-search-line text-foreground-400" />
                </div>
                <input
                  type="text"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder={t('broker_check_placeholder')}
                  className="block w-full pl-10 pr-4 py-3 bg-background-50 border border-background-200 rounded-lg text-foreground-900 placeholder-foreground-400 focus:outline-none focus:border-primary-400 focus:ring-1 focus:ring-primary-400 transition-all text-sm"
                />
              </div>
              <button
                type="submit"
                className="shrink-0 inline-flex items-center justify-center gap-2 px-5 py-3 bg-primary-600 hover:bg-primary-700 text-white rounded-lg text-sm font-medium transition-all whitespace-nowrap w-full sm:w-auto"
              >
                {t('broker_check_button')}
                <i className="ri-arrow-right-line" />
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}