import { useState, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { Link } from 'react-router-dom';
import { newsItems } from '@/mocks/news';
import { usefulLinks } from '@/mocks/links';

const tabs = [
  { key: 'tab_updates', value: 'updates' },
  { key: 'tab_announcements', value: 'announcements' },
  { key: 'tab_circulars', value: 'circulars' },
  { key: 'tab_decisions', value: 'decisions' },
];

export default function ContentGrid() {
  const { t } = useTranslation('common');
  const [activeTab, setActiveTab] = useState('updates');

  const filteredNews = useMemo(() => {
    return newsItems.filter((item) => item.category === activeTab).slice(0, 4);
  }, [activeTab]);

  return (
    <section id="latest" className="py-12 md:py-20 bg-background-50">
      <div className="w-full px-4 md:px-8 lg:px-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12">
          {/* Useful Links - left column */}
          <div className="lg:col-span-5">
            <h2 className="text-xl md:text-2xl font-heading font-semibold text-foreground-900 mb-6">
              {t('useful_links')}
            </h2>
            <div className="grid grid-cols-2 gap-3">
              {usefulLinks.map((link) => (
                <a
                  key={link.id}
                  href={link.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group relative overflow-hidden rounded-lg aspect-[4/3] block"
                >
                  <img
                    src={link.image}
                    alt={link.title}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-background-950/80 via-background-950/40 to-transparent" />
                  <div className="absolute bottom-0 left-0 right-0 p-3 md:p-4">
                    <div className="flex items-center justify-between">
                      <span className="text-xs md:text-sm font-semibold text-white">
                        {t(link.title as never) || link.title}
                      </span>
                      <i className="ri-arrow-right-s-line text-white/70 group-hover:text-accent-400 transition-colors" />
                    </div>
                  </div>
                </a>
              ))}
            </div>
          </div>

          {/* Latest Updates - right column */}
          <div className="lg:col-span-7">
            <h2 className="text-xl md:text-2xl font-heading font-semibold text-foreground-900 mb-6">
              {t('latest_updates')}
            </h2>

            {/* Tabs */}
            <div className="flex flex-wrap gap-1 mb-6 bg-background-200/70 rounded-lg p-1">
              {tabs.map((tab) => (
                <button
                  key={tab.value}
                  onClick={() => setActiveTab(tab.value)}
                  className={`px-4 py-2 rounded-md text-xs md:text-sm font-medium transition-all whitespace-nowrap ${
                    activeTab === tab.value
                      ? 'bg-primary-600 text-white'
                      : 'text-foreground-600 hover:text-foreground-900 hover:bg-background-100'
                  }`}
                >
                  {t(tab.key)}
                </button>
              ))}
            </div>

            {/* News list */}
            <div className="space-y-4">
              {filteredNews.map((item) => (
                <div
                  key={item.id}
                  className="group flex flex-col md:flex-row md:items-start gap-3 p-4 rounded-lg bg-background-100 hover:bg-background-200/70 transition-all border border-transparent hover:border-background-300/60"
                >
                  <div className="text-xs md:text-sm font-medium text-foreground-500 whitespace-nowrap md:w-28 shrink-0">
                    {item.date}
                  </div>
                  <div className="flex-1">
                    <p className="text-sm text-foreground-800 group-hover:text-foreground-900 transition-colors leading-relaxed mb-2">
                      {item.title}
                    </p>
                    <a
                      href={item.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-xs font-medium text-primary-600 hover:text-primary-700 transition-colors"
                    >
                      {t('learn_more')}
                      <i className="ri-arrow-right-line" />
                    </a>
                  </div>
                </div>
              ))}
            </div>

            {/* View all button */}
            <div className="mt-6 flex justify-end">
              <a
                href="https://www.cysec.gov.cy/en-GB/public-info/"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-5 py-2.5 bg-accent-600 hover:bg-accent-700 text-white rounded-md text-sm font-medium transition-all whitespace-nowrap"
              >
                {t('view_all')}
                <i className="ri-arrow-right-line" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}