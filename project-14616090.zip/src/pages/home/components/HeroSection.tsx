import { useTranslation } from 'react-i18next';
import { Link } from 'react-router-dom';

export default function HeroSection() {
  const { t } = useTranslation('common');

  return (
    <section id="hero" className="relative h-[420px] md:h-[600px] w-full overflow-hidden flex items-center">
      {/* Background image */}
      <div className="absolute inset-0">
        <img
          src="https://readdy.ai/api/search-image?query=Modern%20financial%20district%20skyline%20at%20golden%20hour%2C%20Nicosia%20Cyprus%20cityscape%20with%20glass%20office%20buildings%2C%20warm%20amber%20and%20deep%20teal%20sky%20gradient%2C%20professional%20corporate%20photography%20style%2C%20clean%20composition%2C%20dramatic%20lighting%20with%20long%20shadows%2C%20no%20text&width=1600&height=900&seq=hero-bg&orientation=landscape"
          alt="Cyprus financial district"
          className="w-full h-full object-cover"
        />
      </div>

      {/* Dark overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-background-950/70 via-background-950/60 to-background-950/80" />

      {/* Content */}
      <div className="relative z-10 w-full px-4 md:px-8 lg:px-12">
        <div className="max-w-4xl">
          <h1 className="text-2xl md:text-4xl lg:text-5xl font-heading font-bold text-white leading-tight mb-4 md:mb-6">
            {t('hero_title')}
          </h1>
          <p className="text-base md:text-lg text-foreground-200 mb-6 md:mb-8 max-w-2xl leading-relaxed">
            {t('hero_subtitle')}
          </p>
          <Link
            to="/about"
            className="inline-flex items-center gap-2 px-6 py-3 bg-primary-600 hover:bg-primary-700 text-white rounded-md font-medium text-sm transition-all whitespace-nowrap"
          >
            {t('hero_cta')}
            <i className="ri-arrow-right-line" />
          </Link>
        </div>
      </div>
    </section>
  );
}