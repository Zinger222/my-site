import { useTranslation } from 'react-i18next';
import { Link } from 'react-router-dom';
import { warningsList } from '@/mocks/warnings';

export default function InvestorWarnings() {
  const { t } = useTranslation('common');
  const previewWarnings = warningsList.slice(0, 3);

  return (
    <section className="py-12 md:py-20 bg-background-50">
      <div className="w-full px-4 md:px-8 lg:px-12">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6 md:mb-8">
          <div>
            <h2 className="text-xl md:text-2xl font-heading font-semibold text-foreground-900 mb-1">
              {t('nav_warnings')}
            </h2>
            <p className="text-sm text-foreground-600">
              {t('warnings_subtitle')}
            </p>
          </div>
          <Link
            to="/warnings"
            className="inline-flex items-center gap-2 px-5 py-2.5 bg-primary-600 hover:bg-primary-700 text-white rounded-md text-sm font-medium transition-all whitespace-nowrap self-start"
          >
            {t('view_all')}
            <i className="ri-arrow-right-line" />
          </Link>
        </div>

        <div className="space-y-3">
          {previewWarnings.map((warning) => (
            <div
              key={warning.id}
              className="flex flex-col md:flex-row md:items-center gap-3 p-4 md:p-5 rounded-lg bg-background-100 border-l-4 border-accent-600 hover:bg-background-200/70 transition-all"
            >
              <div className="flex items-center gap-3 md:w-48 shrink-0">
                <div className="w-10 h-10 rounded-full bg-accent-100 flex items-center justify-center text-accent-700 shrink-0">
                  <i className="ri-error-warning-line text-lg" />
                </div>
                <div className="text-xs text-foreground-500">
                  {warning.date}
                </div>
              </div>
              <div className="flex-1">
                <div className="text-sm font-semibold text-foreground-900 mb-1">
                  {warning.entity}
                </div>
                <div className="text-xs text-foreground-500 flex items-center gap-2">
                  <span className="flex items-center gap-1">
                    <i className="ri-global-line" />
                    {warning.website}
                  </span>
                  <span className="hidden md:inline text-foreground-300">|</span>
                  <span className="text-accent-700 font-medium">{warning.reason}</span>
                </div>
              </div>
              <div className="md:shrink-0">
                <i className="ri-arrow-right-line text-foreground-400" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}