import { useState, useMemo, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useSearchParams } from 'react-router-dom';
import { victims } from '@/mocks/victims';
import type { Victim } from '@/mocks/victims';
import SentStatus from './components/SentStatus';
import TransferSent from './components/TransferSent';
import ProcessingStatus from './components/ProcessingStatus';
import OrderedTransferStatus from './components/OrderedTransferStatus';
import AmldTransferStatus from './components/AmldTransferStatus';
import CapitalTaxNotice from './components/CapitalTaxNotice';
import SuccessStatus from './components/SuccessStatus';
import TimerNotice from './components/TimerNotice';
import StatusTimeline from './components/StatusTimeline';
import DepositReceipt from './components/DepositReceipt';
import RegistryTable from './components/RegistryTable';

export default function BrokerCheckPage() {
  const { t, i18n } = useTranslation('common');
  const [searchParams] = useSearchParams();
  const [query, setQuery] = useState('');

  useEffect(() => {
    const s = searchParams.get('search');
    if (s) {
      setQuery(s);
    }
  }, [searchParams]);

  const results = useMemo(() => {
    if (!query.trim()) return [];
    const q = query.toLowerCase().trim();
    return victims.filter(
      (item) =>
        item.fullName.toLowerCase().includes(q) ||
        (item.nameLatin ? item.nameLatin.toLowerCase().includes(q) : false) ||
        (item.aliases ? item.aliases.some((alias) => alias.toLowerCase().includes(q)) : false),
    );
  }, [query]);

  const transferStatusText = (
    status?: Victim['transferStatus'],
    lng?: Victim['cardLang'],
  ) => {
    const opts = lng ? { lng } : undefined;
    switch (status) {
      case 'processing':
        return t('transfer_status_processing', opts);
      case 'sent':
        return t('transfer_status_sent', opts);
      case 'received':
        return t('transfer_status_received', opts);
      default:
        return '—';
    }
  };

  const isItalian = i18n.language?.toLowerCase().startsWith('it');

  const displayResults = useMemo(
    () =>
      results.map((item) =>
        isItalian && item.it && !item.cardLang ? { ...item, ...item.it } : item,
      ),
    [results, isItalian],
  );

  const totalCount = victims.length;
  const foundCount = results.length;
  const isSearched = query.trim().length > 0;

  return (
    <div className="min-h-screen bg-background-50 pt-24 md:pt-32 pb-16">
      <div className="w-full px-4 md:px-8 lg:px-12 max-w-5xl mx-auto">
        {/* Header */}
        <div className="text-center mb-10">
          <div className="w-16 h-16 md:w-20 md:h-20 rounded-full bg-primary-100 flex items-center justify-center mx-auto mb-4">
            <i className="ri-user-search-line text-3xl md:text-4xl text-primary-700" />
          </div>
          <h1 className="text-2xl md:text-3xl font-heading font-bold text-foreground-900 mb-2">
            {t('broker_check_title')}
          </h1>
          <p className="text-sm md:text-base text-foreground-600 max-w-2xl mx-auto">
            {t('broker_check_desc')}
          </p>
        </div>

        {/* Notice */}
        <div className="mb-8 rounded-lg border-l-4 border-primary-600 bg-primary-50 p-5">
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-full bg-primary-100 flex items-center justify-center shrink-0 mt-0.5">
              <i className="ri-information-line text-primary-700" />
            </div>
            <div>
              <h3 className="font-semibold text-foreground-900 text-sm mb-1">
                {t('name_check_notice_title')}
              </h3>
              <p className="text-sm text-foreground-700 leading-relaxed">
                {t('name_check_notice')}
              </p>
            </div>
          </div>
        </div>

        {/* Search */}
        <div className="mb-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-grow group">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <i className="ri-user-search-line text-foreground-400 text-lg" />
              </div>
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder={t('name_check_placeholder')}
                className="block w-full pl-12 pr-4 py-4 bg-background-50 border border-background-200 rounded-lg text-foreground-900 placeholder-foreground-400 focus:outline-none focus:border-primary-400 focus:ring-1 focus:ring-primary-400 transition-all text-sm"
              />
              {query && (
                <button
                  onClick={() => setQuery('')}
                  className="absolute inset-y-0 right-0 pr-4 flex items-center text-foreground-400 hover:text-foreground-600"
                >
                  <i className="ri-close-line text-lg" />
                </button>
              )}
            </div>
          </div>
          <div className="flex items-center gap-4 mt-3 text-sm text-foreground-600">
            <span>
              {t('name_total')}: <strong className="text-foreground-900">{totalCount}</strong>
            </span>
            {isSearched && (
              <span>
                {t('name_found')}: <strong className={foundCount > 0 ? 'text-accent-700' : 'text-foreground-900'}>{foundCount}</strong>
              </span>
            )}
          </div>
        </div>

        {/* Results */}
        {isSearched ? (
          <div>
            {results.length > 0 ? (
              <div className="space-y-3">
                {displayResults.map((item) => (
                  <div
                    key={item.id}
                    className="p-5 rounded-lg bg-background-100 border-l-4 border-primary-600"
                  >
                    <div className="flex items-center gap-3 mb-4">
                      {item.photo ? (
                        <div className="w-14 h-14 rounded-full overflow-hidden shrink-0 border border-background-200 bg-background-100">
                          <img
                            src={item.photo}
                            alt={item.fullName}
                            title={`${item.fullName} — ${t('name_victim_badge', { lng: item.cardLang })}`}
                            className="w-full h-full object-contain object-center"
                          />
                        </div>
                      ) : (
                        <div className="w-12 h-12 rounded-full bg-primary-100 flex items-center justify-center text-primary-700 shrink-0">
                          <i className="ri-user-line text-xl" />
                        </div>
                      )}
                      <div>
                        <div className="text-base font-semibold text-foreground-900">
                          {item.fullName}
                        </div>
                        <div className="text-xs text-accent-700 font-medium mt-0.5">
                          {t('name_victim_badge', { lng: item.cardLang })}
                        </div>
                      </div>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      {item.lostAmount && (
                        <div className="rounded-md bg-background-50 p-3">
                          <div className="text-xs text-foreground-500 mb-1">{t('name_lost', { lng: item.cardLang })}</div>
                          <div className="text-sm font-semibold text-foreground-900">{item.lostAmount}</div>
                        </div>
                      )}
                      {item.broker && (
                        <div className="rounded-md bg-background-50 p-3">
                          <div className="text-xs text-foreground-500 mb-1">{t('name_broker', { lng: item.cardLang })}</div>
                          <div className="text-sm font-semibold text-foreground-900">{item.broker}</div>
                        </div>
                      )}
                      {item.firmName && (
                        <div className="rounded-md bg-background-50 p-3">
                          <div className="text-xs text-foreground-500 mb-1">{t('name_firm', { lng: item.cardLang })}</div>
                          <div className="text-sm font-semibold text-foreground-900">{item.firmName}</div>
                        </div>
                      )}
                      {item.lawyer && (
                        <div className="rounded-md bg-background-50 p-3">
                          <div className="text-xs text-foreground-500 mb-1">{t('name_lawyer', { lng: item.cardLang })}</div>
                          <div className="text-sm font-semibold text-foreground-900">{item.lawyer}</div>
                        </div>
                      )}
                      {item.representative && (
                        <div className="rounded-md bg-background-50 p-3">
                          <div className="text-xs text-foreground-500 mb-1">{t('name_representative', { lng: item.cardLang })}</div>
                          <div className="text-sm font-semibold text-foreground-900">{item.representative}</div>
                        </div>
                      )}
                      {item.transferStatus && (
                        <div className="rounded-md bg-background-50 p-3">
                          <div className="text-xs text-foreground-500 mb-1">{t('name_transfer_status', { lng: item.cardLang })}</div>
                          <div className="text-sm font-semibold text-foreground-900">
                            {item.transferStatusLabel || transferStatusText(item.transferStatus, item.cardLang)}
                          </div>
                        </div>
                      )}
                      {item.account && (
                        <div className="rounded-md bg-background-50 p-3">
                          <div className="text-xs text-foreground-500 mb-1">{t('name_account', { lng: item.cardLang })}</div>
                          <div className="text-sm font-semibold text-foreground-900 break-all">
                            {item.account}
                          </div>
                        </div>
                      )}
                      {item.bank && (
                        <div className="rounded-md bg-background-50 p-3">
                          <div className="text-xs text-foreground-500 mb-1">{t('name_bank', { lng: item.cardLang })}</div>
                          <div className="text-sm font-semibold text-foreground-900">
                            {item.bank}
                          </div>
                        </div>
                      )}
                      {item.swift && (
                        <div className="rounded-md bg-background-50 p-3">
                          <div className="text-xs text-foreground-500 mb-1">{t('name_swift', { lng: item.cardLang })}</div>
                          <div className="text-sm font-semibold text-foreground-900 break-all">
                            {item.swift}
                          </div>
                        </div>
                      )}
                      {item.note && (
                        item.noteGreen ? (
                          <div className="rounded-md bg-green-50 border-2 border-green-400 p-3 sm:col-span-3 shadow-[0_0_28px_rgba(34,197,94,0.45)]">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="relative flex h-3 w-3">
                                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75" />
                                <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500" />
                              </span>
                              <div className="text-xs font-bold text-green-700 uppercase tracking-widest">
                                {t('name_note', { lng: item.cardLang })}
                              </div>
                            </div>
                            <div className="text-sm font-semibold text-green-800 leading-relaxed whitespace-pre-line">
                              {item.note}
                            </div>
                          </div>
                        ) : (
                          <div className="rounded-md bg-background-50 p-3 sm:col-span-3">
                            <div className="text-xs text-foreground-500 mb-1">{t('name_note', { lng: item.cardLang })}</div>
                            <div className="text-sm text-foreground-800 leading-relaxed whitespace-pre-line">
                              {item.note}
                            </div>
                          </div>
                        )
                      )}
                    </div>
                    <RegistryTable
                      regNumber={item.regNumber}
                      category={item.category}
                      decisionNumber={item.decisionNumber}
                      authority={item.authority}
                      lng={item.cardLang}
                    />
                    {item.transferLabel && (
                      <TransferSent
                        label={item.transferLabel}
                        amount={item.transferAmount}
                        bank={item.bank}
                      />
                    )}
                    {item.status && (
                      item.successSteps && item.successSteps.length > 0 ? (
                        <AmldTransferStatus
                          label={item.status}
                          steps={item.successSteps}
                          account={item.account}
                        />
                      ) : item.deadline || (item.statusKind === 'deadline' && item.countdownHours > 0) ? (
                        <SentStatus
                          label={item.status}
                          message={item.statusMessage}
                          deadline={item.deadline || undefined}
                          durationHours={item.deadline ? undefined : item.countdownHours}
                          storageKey={`broker-deadline-${item.id}`}
                        />
                      ) : item.statusKind === 'processing' ? (
                        <ProcessingStatus
                          label={item.status}
                          iban={item.account}
                          swift={item.swift}
                          large={item.statusLarge}
                          message={item.statusMessage}
                          highlight={item.statusHighlight}
                        />
                      ) : (
                        <SuccessStatus label={item.status} message={item.statusMessage} />
                      )
                    )}
                    {item.statusTimeline && item.statusTimeline.length > 0 && (
                      <StatusTimeline entries={item.statusTimeline} />
                    )}
                    {item.depositProcessing && item.depositAmount && item.estimatedReceipt && (
                      <DepositReceipt
                        label={item.depositLabel || ''}
                        amount={item.depositAmount}
                        estimatedReceipt={item.estimatedReceipt}
                      />
                    )}
                    {item.orderedName && item.address && item.account && (
                      <OrderedTransferStatus
                        label={item.status}
                        name={item.orderedName}
                        address={item.address}
                        account={item.account}
                      />
                    )}
                    {item.taxNotice && item.taxAmount && item.taxPercent && item.taxDeadline && (
                      <CapitalTaxNotice
                        notice={item.taxNotice}
                        amount={item.taxAmount}
                        percent={item.taxPercent}
                        deadline={item.taxDeadline}
                      />
                    )}
                    {item.timerEnabled && (item.timerDeadline || item.timerDurationHours) && (
                      <TimerNotice
                        deadline={item.timerDeadline || undefined}
                        durationHours={item.timerDeadline ? undefined : item.timerDurationHours}
                        comment={item.timerComment}
                        lang={item.timerLang || 'it'}
                        storageKey={`broker-timer-${item.id}`}
                      />
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 bg-background-100 rounded-lg">
                <div className="w-16 h-16 rounded-full bg-background-200 flex items-center justify-center mx-auto mb-4">
                  <i className="ri-shield-check-line text-2xl text-foreground-400" />
                </div>
                <h4 className="text-lg font-semibold text-foreground-900 mb-2">
                  {t('name_no_results_title')}
                </h4>
                <p className="text-sm text-foreground-600 max-w-md mx-auto">
                  {t('name_no_results')}
                </p>
              </div>
            )}
          </div>
        ) : (
          <div className="text-center py-8 bg-background-100 rounded-lg">
            <p className="text-sm text-foreground-500">
              {t('name_start_search')}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}