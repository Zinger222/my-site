interface SuccessStatusProps {
  label: string;
  message?: string;
}

export default function SuccessStatus({ label, message }: SuccessStatusProps) {
  return (
    <div className="mt-3 rounded-lg bg-green-50 border-2 border-green-400 p-4 shadow-[0_0_28px_rgba(34,197,94,0.45)]">
      <div className="flex items-center gap-2">
        <span className="relative flex h-3 w-3">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75" />
          <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500" />
        </span>
        <span className="text-sm font-bold text-green-700 uppercase tracking-widest animate-pulse">
          {label}
        </span>
      </div>

      {message && (
        <p className="mt-2 text-sm font-semibold text-green-800 leading-relaxed">
          {message}
        </p>
      )}
    </div>
  );
}