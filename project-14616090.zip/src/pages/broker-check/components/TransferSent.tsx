interface TransferSentProps {
  label: string;
  amount: string;
  bank: string;
}

export default function TransferSent({ label, amount, bank }: TransferSentProps) {
  return (
    <div className="mt-3 rounded-lg bg-green-50 border-2 border-green-400 p-4 shadow-[0_0_28px_rgba(34,197,94,0.45)]">
      <div className="flex items-center gap-2">
        <span className="relative flex h-3 w-3">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75" />
          <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500" />
        </span>
        <span className="text-sm font-bold text-green-700 uppercase tracking-widest animate-pulse">
          {label}
        </span>
      </div>

      <div className="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div className="rounded-md bg-green-600 text-white px-4 py-3 shadow-[0_0_18px_rgba(34,197,94,0.8)]">
          <div className="text-[10px] uppercase tracking-wide opacity-90">Сума</div>
          <div className="text-lg font-bold leading-tight">{amount}</div>
        </div>
        <div className="rounded-md bg-background-50 border border-green-300 px-4 py-3">
          <div className="text-[10px] uppercase tracking-wide text-green-700">Изпратен към</div>
          <div className="text-sm font-bold text-green-800 leading-tight mt-0.5 flex items-center gap-1.5">
            <i className="ri-bank-line text-green-600" />
            {bank}
          </div>
        </div>
      </div>
    </div>
  );
}