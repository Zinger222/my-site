interface OrderedTransferStatusProps {
  label: string;
  name: string;
  address: string;
  account: string;
}

export default function OrderedTransferStatus({
  label,
  name,
  address,
  account,
}: OrderedTransferStatusProps) {
  const rows: { label: string; value: string; icon: string }[] = [
    { label: 'Име / Name', value: name, icon: 'ri-user-line' },
    { label: 'Адрес / Address', value: address, icon: 'ri-map-pin-line' },
    { label: 'Сметка на наредителя / Sender\u2019s account', value: account, icon: 'ri-bank-card-line' },
  ];

  return (
    <div className="mt-3 rounded-lg bg-green-50 border-2 border-green-400 p-4 shadow-[0_0_28px_rgba(34,197,94,0.5)]">
      <div className="flex items-center gap-2">
        <span className="relative flex h-3 w-3">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75" />
          <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500" />
        </span>
        <span className="text-sm font-bold text-green-700 uppercase tracking-widest animate-pulse">
          {label}
        </span>
      </div>

      <div className="mt-3 space-y-2">
        {rows.map((row) => (
          <div
            key={row.label}
            className="rounded-md bg-background-50 border border-green-300 px-4 py-3 flex items-start gap-3"
          >
            <div className="w-8 h-8 rounded-full bg-green-100 text-green-700 flex items-center justify-center shrink-0 mt-0.5">
              <i className={`${row.icon} text-base`} />
            </div>
            <div className="min-w-0">
              <div className="text-[10px] uppercase tracking-wide text-green-700 font-medium">
                {row.label}
              </div>
              <div className="text-sm font-bold text-green-800 leading-tight mt-0.5 break-words">
                {row.value}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}