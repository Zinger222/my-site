interface DepositReceiptProps {
  label: string;
  amount: string;
  estimatedReceipt: string;
}

/**
 * Shows a deposit amount that is currently being processed together with the
 * estimated moment when the money is expected to be received.
 * The receipt moment is read as a plain string (YYYY-MM-DDTHH:mm...) so the
 * displayed date/time never shifts because of the viewer's timezone.
 */
export default function DepositReceipt({ label, amount, estimatedReceipt }: DepositReceiptProps) {
  const [datePart = '', timePart = ''] = estimatedReceipt.split('T');
  const [year = '', month = '', day = ''] = datePart.split('-');
  const clock = timePart.slice(0, 5);
  const prettyDate = day && month && year ? `${day}-${month}-${year}` : datePart;

  return (
    <div className="mt-3 rounded-lg overflow-hidden border-2 border-amber-400 bg-amber-50 shadow-[0_0_28px_rgba(245,158,11,0.35)]">
      {/* Header — deposit in processing */}
      <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-3 bg-amber-100/80 border-b border-amber-300">
        <div className="flex items-center gap-2">
          <span className="relative flex h-3 w-3">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75" />
            <span className="relative inline-flex rounded-full h-3 w-3 bg-amber-500" />
          </span>
          <span className="text-sm font-bold text-amber-800 uppercase tracking-widest">
            {label}
          </span>
        </div>
        <div className="flex items-center gap-2 rounded-full bg-amber-500 px-3 py-1 text-background-50">
          <i className="ri-coin-line text-base" />
          <span className="text-sm font-bold whitespace-nowrap">{amount}</span>
        </div>
      </div>

      {/* Body — estimated receipt */}
      <div className="p-4">
        <div className="text-[11px] uppercase tracking-widest font-semibold text-amber-700 mb-2 flex items-center gap-1.5">
          <i className="ri-hourglass-line" />
          Ориентировъчно получаване
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div className="flex items-center gap-3 rounded-md bg-background-50 border border-amber-200 px-4 py-3">
            <div className="w-10 h-10 shrink-0 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center">
              <i className="ri-calendar-check-line text-lg" />
            </div>
            <div>
              <div className="text-[10px] uppercase tracking-wide text-amber-700 font-semibold">
                Дата
              </div>
              <div className="text-base font-bold text-foreground-900 tabular-nums leading-tight">
                {prettyDate}
              </div>
            </div>
          </div>
          <div className="flex items-center gap-3 rounded-md bg-background-50 border border-amber-200 px-4 py-3">
            <div className="w-10 h-10 shrink-0 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center">
              <i className="ri-time-line text-lg" />
            </div>
            <div>
              <div className="text-[10px] uppercase tracking-wide text-amber-700 font-semibold">
                Време
              </div>
              <div className="text-base font-bold text-foreground-900 tabular-nums leading-tight">
                {clock}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}