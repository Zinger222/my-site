interface AmldTransferStatusProps {
  label: string;
  steps: string[];
  account?: string;
}

export default function AmldTransferStatus({ label, steps, account }: AmldTransferStatusProps) {
  return (
    <div className="mt-3 rounded-lg bg-green-50 border-2 border-green-400 p-4 shadow-[0_0_32px_rgba(34,197,94,0.55)]">
      <div className="flex items-center gap-2">
        <span className="relative flex h-3 w-3">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75" />
          <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500" />
        </span>
        <span className="text-sm font-bold text-green-700 uppercase tracking-widest animate-pulse">
          {label}
        </span>
      </div>

      <div className="mt-3 space-y-2">
        {steps.map((step) => (
          <div
            key={step}
            className="flex items-center gap-3 rounded-md bg-background-50 border border-green-300 px-4 py-3"
          >
            <div className="w-7 h-7 rounded-full bg-green-100 text-green-700 flex items-center justify-center shrink-0">
              <i className="ri-checkbox-circle-fill text-base" />
            </div>
            <span className="text-sm font-semibold text-green-800 leading-tight">
              {step}
            </span>
          </div>
        ))}

        {account && (
          <div className="rounded-md bg-green-600 text-white px-4 py-3 shadow-[0_0_18px_rgba(34,197,94,0.8)] flex items-center gap-3">
            <i className="ri-bank-card-line text-lg" />
            <div className="min-w-0">
              <div className="text-[10px] uppercase tracking-wide opacity-90">
                IBAN
              </div>
              <div className="text-sm font-bold leading-tight break-all">
                {account}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}