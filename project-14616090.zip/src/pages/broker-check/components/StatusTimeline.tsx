interface StatusTimelineEntry {
  time: string;
  text: string;
  kind?: 'done' | 'pending';
}

interface StatusTimelineProps {
  entries: StatusTimelineEntry[];
}

export default function StatusTimeline({ entries }: StatusTimelineProps) {
  if (!entries || entries.length === 0) return null;

  return (
    <div className="mt-3 rounded-lg bg-background-100 border border-background-200 p-4">
      <div className="flex items-center gap-2 mb-3">
        <div className="w-7 h-7 rounded-full bg-primary-100 text-primary-700 flex items-center justify-center shrink-0">
          <i className="ri-history-line text-base" />
        </div>
        <span className="text-sm font-bold text-foreground-900 uppercase tracking-wide">
          История на превода
        </span>
      </div>

      <ol className="relative space-y-3 pl-6">
        <span className="absolute left-[6px] top-2 bottom-2 w-px bg-background-300" aria-hidden="true" />
        {entries.map((entry, index) => {
          const isDone = entry.kind !== 'pending';
          return (
            <li key={`${entry.time}-${index}`} className="relative">
              <span
                className={
                  isDone
                    ? 'absolute -left-6 top-0.5 w-3.5 h-3.5 rounded-full bg-green-500 border-2 border-background-100'
                    : 'absolute -left-6 top-0.5 w-3.5 h-3.5 rounded-full bg-yellow-400 border-2 border-background-100'
                }
                aria-hidden="true"
              />
              <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5">
                <span
                  className={
                    isDone
                      ? 'text-xs font-bold text-green-700 tabular-nums'
                      : 'text-xs font-bold text-yellow-700 tabular-nums'
                  }
                >
                  {entry.time}
                </span>
                {!isDone && (
                  <span className="text-[10px] uppercase tracking-wide font-semibold text-yellow-700 bg-yellow-100 rounded-full px-2 py-0.5">
                    Очаква се
                  </span>
                )}
              </div>
              <p className="text-sm text-foreground-800 leading-relaxed mt-0.5">
                {entry.text}
              </p>
            </li>
          );
        })}
      </ol>
    </div>
  );
}