import { useEffect, useState } from 'react';

interface CapitalTaxNoticeProps {
  notice: string;
  amount: string;
  percent: string;
  deadline: string;
}

const pad = (n: number) => String(n).padStart(2, '0');

export default function CapitalTaxNotice({
  notice,
  amount,
  percent,
  deadline,
}: CapitalTaxNoticeProps) {
  const target = new Date(deadline).getTime();
  const [remaining, setRemaining] = useState(() => Math.max(0, target - Date.now()));

  useEffect(() => {
    const tick = () => setRemaining(Math.max(0, target - Date.now()));
    tick();
    const timer = setInterval(tick, 1000);
    return () => clearInterval(timer);
  }, [target]);

  const totalSeconds = Math.floor(remaining / 1000);
  const h = Math.floor(totalSeconds / 3600);
  const m = Math.floor((totalSeconds % 3600) / 60);
  const s = totalSeconds % 60;

  const blocks: { value: string; unit: string }[] = [
    { value: pad(h), unit: 'часа' },
    { value: pad(m), unit: 'мин' },
    { value: pad(s), unit: 'сек' },
  ];

  return (
    <div className="mt-3 rounded-lg bg-red-50 border-2 border-red-400 p-4 shadow-[0_0_28px_rgba(239,68,68,0.45)]">
      <div className="flex items-start gap-2">
        <div className="w-7 h-7 rounded-full bg-red-100 text-red-600 flex items-center justify-center shrink-0 mt-0.5">
          <i className="ri-alert-line text-sm" />
        </div>
        <p className="text-sm text-red-800 leading-relaxed">{notice}</p>
      </div>

      <div className="mt-4 rounded-lg bg-red-600 text-white px-4 py-5 text-center shadow-[0_0_24px_rgba(239,68,68,0.7)]">
        <div className="text-[11px] uppercase tracking-widest opacity-90">
          Дължим данък
        </div>
        <div className="text-4xl md:text-5xl font-bold leading-none mt-3 tabular-nums">
          {amount}
        </div>
        <div className="mt-2 text-sm font-semibold opacity-95">({percent})</div>
      </div>

      <div className="mt-4">
        <div className="text-xs text-red-700 font-medium mb-2 text-center">
          Оставащо време за плащане
        </div>
        <div className="flex items-center justify-center gap-2">
          {blocks.map((block) => (
            <div
              key={block.unit}
              className="flex flex-col items-center justify-center min-w-[64px] px-3 py-2 rounded-md bg-red-600 text-white shadow-[0_0_18px_rgba(239,68,68,0.8)]"
            >
              <span className="text-xl font-bold tabular-nums leading-none">
                {block.value}
              </span>
              <span className="text-[10px] uppercase tracking-wide mt-1 opacity-90">
                {block.unit}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}