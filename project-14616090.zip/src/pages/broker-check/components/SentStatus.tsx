import { useEffect, useState } from 'react';

interface SentStatusProps {
  label: string;
  message: string;
  deadline?: string;
  durationHours?: number;
  storageKey?: string;
}

const pad = (n: number) => String(n).padStart(2, '0');

/**
 * Resolve the fixed target moment once. When a storageKey is provided and no
 * deadline is set, the start moment is persisted so the countdown starts the
 * first time the card is opened and does not restart on every re-search.
 */
const resolveTarget = (deadline?: string, durationHours?: number, storageKey?: string) => {
  if (deadline) return new Date(deadline).getTime();
  const durationMs = (durationHours ?? 0) * 60 * 60 * 1000;
  if (storageKey) {
    try {
      const stored = window.localStorage.getItem(storageKey);
      if (stored) {
        const parsed = Number(stored);
        if (Number.isFinite(parsed) && parsed > 0) return parsed;
      }
      const next = Date.now() + durationMs;
      window.localStorage.setItem(storageKey, String(next));
      return next;
    } catch {
      // localStorage unavailable (private mode, etc.) — fall back to now
    }
  }
  return Date.now() + durationMs;
};

export default function SentStatus({
  label,
  message,
  deadline,
  durationHours,
  storageKey,
}: SentStatusProps) {
  const [target] = useState(() => resolveTarget(deadline, durationHours, storageKey));
  const [remaining, setRemaining] = useState(() => Math.max(0, target - Date.now()));

  useEffect(() => {
    const tick = () => setRemaining(Math.max(0, target - Date.now()));
    tick();
    const timer = setInterval(tick, 1000);
    return () => clearInterval(timer);
  }, [target]);

  const totalSeconds = Math.floor(remaining / 1000);
  const days = Math.floor(totalSeconds / 86400);
  const h = Math.floor((totalSeconds % 86400) / 3600);
  const m = Math.floor((totalSeconds % 3600) / 60);
  const s = totalSeconds % 60;

  const blocks: { value: string; unit: string }[] =
    days > 0
      ? [
          { value: pad(days), unit: 'дни' },
          { value: pad(h), unit: 'часа' },
          { value: pad(m), unit: 'мин' },
          { value: pad(s), unit: 'сек' },
        ]
      : [
          { value: pad(h), unit: 'часа' },
          { value: pad(m), unit: 'мин' },
          { value: pad(s), unit: 'сек' },
        ];

  return (
    <div className="mt-3 rounded-lg bg-red-50 border-2 border-red-400 p-4 shadow-[0_0_28px_rgba(239,68,68,0.45)]">
      <div className="flex items-center gap-2">
        <span className="relative flex h-3 w-3">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75" />
          <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500" />
        </span>
        <span className="text-sm font-bold text-red-700 uppercase tracking-widest animate-pulse">
          {label}
        </span>
      </div>

      <p className="mt-2 text-sm font-semibold text-red-800 leading-relaxed">
        {message}
      </p>

      <div className="mt-3">
        <div className="text-xs text-red-700 font-medium mb-1.5">
          Оставащо време за плащане
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {blocks.map((block) => (
            <div
              key={block.unit}
              className="flex flex-col items-center justify-center min-w-[64px] px-3 py-2 rounded-md bg-red-600 text-white shadow-[0_0_18px_rgba(239,68,68,0.8)]"
            >
              <span className="text-xl font-bold tabular-nums leading-none">
                {block.value}
              </span>
              <span className="text-[10px] uppercase tracking-wide mt-1 opacity-90">
                {block.unit}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}