interface ProcessingStatusProps {
  label: string;
  iban?: string;
  swift?: string;
  large?: boolean;
  message?: string;
  highlight?: string;
}

export default function ProcessingStatus({ label, iban, swift, large, message, highlight }: ProcessingStatusProps) {
  return (
    <div className="mt-3 rounded-lg bg-yellow-50 border-2 border-yellow-400 p-4 shadow-[0_0_28px_rgba(234,179,8,0.45)]">
      <div className="flex items-center gap-2">
        <span className="relative flex h-3 w-3">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-yellow-400 opacity-75" />
          <span className="relative inline-flex rounded-full h-3 w-3 bg-yellow-500" />
        </span>
        <span
          className={
            large
              ? 'text-2xl md:text-3xl font-extrabold text-yellow-600 uppercase tracking-wide animate-pulse'
              : 'text-sm font-bold text-yellow-700 uppercase tracking-widest animate-pulse'
          }
        >
          {label}
        </span>
      </div>

      {(iban || swift) && (
        <div className="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-3">
          {iban && (
            <div className="rounded-md bg-background-50 border border-yellow-300 px-4 py-3">
              <div className="text-[10px] uppercase tracking-wide text-yellow-700 font-medium">
                IBAN
              </div>
              <div className="text-sm font-bold text-yellow-800 leading-tight mt-0.5 break-all">
                {iban}
              </div>
            </div>
          )}
          {swift && (
            <div className="rounded-md bg-background-50 border border-yellow-300 px-4 py-3">
              <div className="text-[10px] uppercase tracking-wide text-yellow-700 font-medium">
                SWIFT / BIC
              </div>
              <div className="text-sm font-bold text-yellow-800 leading-tight mt-0.5">
                {swift}
              </div>
            </div>
          )}
        </div>
      )}

      {message && (
        <p className="mt-3 text-sm font-medium text-yellow-900 leading-relaxed whitespace-pre-line">
          {message}
        </p>
      )}

      {highlight && (
        <div className="mt-2 text-lg md:text-xl font-extrabold text-yellow-700 tracking-wide">
          {highlight}
        </div>
      )}
    </div>
  );
}