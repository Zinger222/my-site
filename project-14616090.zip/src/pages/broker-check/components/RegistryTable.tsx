import { useTranslation } from 'react-i18next';

interface RegistryTableProps {
  regNumber: string;
  category: string;
  decisionNumber: string;
  authority: string;
  lng?: string;
}

export default function RegistryTable({
  regNumber,
  category,
  decisionNumber,
  authority,
  lng,
}: RegistryTableProps) {
  const { t } = useTranslation('common');
  const opts = lng ? { lng } : undefined;

  const rows = [
    { key: 'reg', label: t('name_reg_number', opts), value: regNumber },
    { key: 'cat', label: t('name_category', opts), value: category },
    { key: 'dec', label: t('name_decision_number', opts), value: decisionNumber },
    { key: 'auth', label: t('name_authority', opts), value: authority },
  ].filter((row) => row.value);

  if (rows.length === 0) {
    return null;
  }

  return (
    <div className="mt-4 rounded-md border border-background-200/70 overflow-hidden divide-y divide-background-200/70">
      {rows.map((row) => (
        <div
          key={row.key}
          className="flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-4 px-3 py-2.5 bg-background-50"
        >
          <span className="text-xs text-foreground-500 sm:w-56 shrink-0">
            {row.label}
          </span>
          <span className="text-sm font-medium text-foreground-900 break-words">
            {row.value}
          </span>
        </div>
      ))}
    </div>
  );
}