import { useEffect, useState } from 'react';

type TimerLang = 'it' | 'bg';

interface TimerNoticeProps {
  deadline?: string;
  durationHours?: number;
  comment?: string;
  lang?: TimerLang;
  storageKey?: string;
}

const LABELS: Record<TimerLang, { title: string; payment: string; days: string; hours: string; min: string; sec: string }> = {
  it: {
    title: 'Tempo rimanente',
    payment: 'Tempo rimanente per il pagamento',
    days: 'giorni',
    hours: 'ore',
    min: 'min',
    sec: 'sec',
  },
  bg: {
    title: 'Оставащо време',
    payment: 'Оставащо време за плащане',
    days: 'дни',
    hours: 'часа',
    min: 'мин',
    sec: 'сек',
  },
};

const pad = (n: number) => String(n).padStart(2, '0');

/**
 * Resolve the fixed target moment once. When a storageKey is provided the
 * start moment is persisted, so the countdown is anchored to the first time
 * the card was opened instead of restarting on every re-render / re-search.
 */
const resolveTarget = (deadline?: string, durationHours?: number, storageKey?: string) => {
  if (deadline) return new Date(deadline).getTime();
  const durationMs = (durationHours ?? 0) * 60 * 60 * 1000;
  if (storageKey) {
    try {
      const stored = window.localStorage.getItem(storageKey);
      if (stored) {
        const parsed = Number(stored);
        if (Number.isFinite(parsed) && parsed > 0) return parsed;
      }
      const next = Date.now() + durationMs;
      window.localStorage.setItem(storageKey, String(next));
      return next;
    } catch {
      // localStorage unavailable (private mode, etc.) — fall back to now
    }
  }
  return Date.now() + durationMs;
};

export default function TimerNotice({ deadline, durationHours, comment, lang = 'it', storageKey }: TimerNoticeProps) {
  const t = LABELS[lang];
  const [target] = useState(() => resolveTarget(deadline, durationHours, storageKey));
  const [remaining, setRemaining] = useState(() => Math.max(0, target - Date.now()));

  useEffect(() => {
    const tick = () => setRemaining(Math.max(0, target - Date.now()));
    tick();
    const timer = setInterval(tick, 1000);
    return () => clearInterval(timer);
  }, [target]);

  const totalSeconds = Math.floor(remaining / 1000);
  const days = Math.floor(totalSeconds / 86400);
  const hours = Math.floor((totalSeconds % 86400) / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;

  const blocks: { value: string; unit: string }[] =
    days > 0
      ? [
          { value: pad(days), unit: t.days },
          { value: pad(hours), unit: t.hours },
          { value: pad(minutes), unit: t.min },
          { value: pad(seconds), unit: t.sec },
        ]
      : [
          { value: pad(hours), unit: t.hours },
          { value: pad(minutes), unit: t.min },
          { value: pad(seconds), unit: t.sec },
        ];

  return (
    <div className="mt-3 rounded-lg bg-red-50 border-2 border-red-400 p-4 shadow-[0_0_28px_rgba(239,68,68,0.45)]">
      <div className="flex items-center gap-2">
        <span className="relative flex h-3 w-3">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75" />
          <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500" />
        </span>
        <span className="text-sm font-bold text-red-700 uppercase tracking-widest animate-pulse">
          {t.title}
        </span>
      </div>

      {comment && (
        <p className="mt-2 text-sm font-semibold text-red-800 leading-relaxed">
          {comment}
        </p>
      )}

      <div className="mt-3">
        <div className="text-xs text-red-700 font-medium mb-1.5">
          {t.payment}
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {blocks.map((block) => (
            <div
              key={block.unit}
              className="flex flex-col items-center justify-center min-w-[64px] px-3 py-2 rounded-md bg-red-600 text-white shadow-[0_0_18px_rgba(239,68,68,0.8)]"
            >
              <span className="text-xl font-bold tabular-nums leading-none">
                {block.value}
              </span>
              <span className="text-[10px] uppercase tracking-wide mt-1 opacity-90">
                {block.unit}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}