import { useTranslation } from 'react-i18next';
import { Link } from 'react-router-dom';

export default function AboutPage() {
  const { t } = useTranslation('common');

  return (
    <div className="min-h-screen bg-background-50">
      {/* Header */}
      <section className="relative h-[280px] md:h-[360px] w-full overflow-hidden flex items-center">
        <div className="absolute inset-0">
          <img
            src="https://readdy.ai/api/search-image?query=Modern%20government%20regulatory%20office%20building%20exterior%20in%20Cyprus%2C%20Mediterranean%20architecture%20with%20glass%20facade%2C%20palm%20trees%2C%20blue%20sky%2C%20warm%20sunlight%2C%20professional%20architectural%20photography%2C%20clean%20corporate%20aesthetic%2C%20no%20people&width=1600&height=900&seq=about-hero&orientation=landscape"
            alt="CySEC Building"
            className="w-full h-full object-cover"
          />
        </div>
        <div className="absolute inset-0 bg-background-950/70" />
        <div className="relative z-10 w-full px-4 md:px-8 lg:px-12">
          <div className="max-w-4xl">
            <h1 className="text-2xl md:text-4xl font-heading font-bold text-white leading-tight mb-3">
              {t('about_title')}
            </h1>
            <p className="text-base text-foreground-200 max-w-2xl leading-relaxed">
              {t('about_subtitle')}
            </p>
          </div>
        </div>
      </section>

      {/* Content */}
      <div className="w-full px-4 md:px-8 lg:px-12 py-10 md:py-16">
        <div className="max-w-4xl mx-auto">
          {/* Vision & Mission */}
          <div className="mb-10 md:mb-14">
            <h2 className="text-xl md:text-2xl font-heading font-semibold text-foreground-900 mb-4">
              {t('about_vision_title')}
            </h2>
            <p className="text-sm md:text-base text-foreground-600 leading-relaxed mb-4">
              {t('about_vision_text')}
            </p>
          </div>

          {/* Responsibilities */}
          <div className="mb-10 md:mb-14">
            <h2 className="text-xl md:text-2xl font-heading font-semibold text-foreground-900 mb-4">
              {t('about_responsibilities_title')}
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[
                'about_resp_1',
                'about_resp_2',
                'about_resp_3',
                'about_resp_4',
                'about_resp_5',
                'about_resp_6',
              ].map((key) => (
                <div
                  key={key}
                  className="flex items-start gap-3 p-4 rounded-lg bg-background-100 border border-background-200/70"
                >
                  <div className="w-8 h-8 flex items-center justify-center rounded-md bg-primary-100 text-primary-700 shrink-0">
                    <i className="ri-check-line text-sm" />
                  </div>
                  <span className="text-sm text-foreground-700 leading-relaxed">
                    {t(key)}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Board */}
          <div className="mb-10 md:mb-14">
            <h2 className="text-xl md:text-2xl font-heading font-semibold text-foreground-900 mb-4">
              {t('about_board_title')}
            </h2>
            <p className="text-sm md:text-base text-foreground-600 leading-relaxed mb-6">
              {t('about_board_text')}
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {[
                { name: 'Dr. George Theocharides', role: 'Chairman' },
                { name: 'Andreas Pitsillides', role: 'Vice Chairman' },
                { name: 'George Pantelis', role: 'Board Member' },
              ].map((member) => (
                <div
                  key={member.name}
                  className="p-5 rounded-lg bg-background-100 border border-background-200/70 text-center"
                >
                  <div className="w-16 h-16 rounded-full bg-primary-100 flex items-center justify-center mx-auto mb-3">
                    <i className="ri-user-line text-2xl text-primary-700" />
                  </div>
                  <div className="text-sm font-semibold text-foreground-900 mb-1">
                    {member.name}
                  </div>
                  <div className="text-xs text-foreground-500">
                    {member.role}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Contact CTA */}
          <div className="p-6 md:p-8 rounded-lg bg-primary-50 border border-primary-200/70 text-center">
            <h3 className="text-lg font-heading font-semibold text-primary-900 mb-2">
              {t('about_contact_title')}
            </h3>
            <p className="text-sm text-primary-700 mb-4">
              {t('about_contact_text')}
            </p>
            <a
              href="https://www.cysec.gov.cy/en-GB/cysec/contact/"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-primary-600 hover:bg-primary-700 text-white rounded-md text-sm font-medium transition-all"
            >
              {t('contact_us')}
              <i className="ri-arrow-right-line" />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}