import { useTranslation } from 'react-i18next';

const legislationCategories = [
  {
    id: 'services-markets',
    title: 'legislation_services_markets',
    items: [
      'Investment Services and Activities and Regulated Markets Law of 2017 (Law 87(I)/2017)',
      'Markets in Financial Instruments Regulation (MiFIR)',
      'DLT Pilot Regime Regulation',
      'EMIR Regulation',
      'SFTR Regulation',
      'CSD Regulation',
      'CRA Regulation',
    ],
  },
  {
    id: 'collective-investment',
    title: 'legislation_collective',
    items: [
      'UCITS Law of 2012 (Law 78(I)/2012)',
      'Alternative Investment Funds Law of 2018 (Law 124(I)/2018)',
      'AIFM Law of 2013 (Law 37(I)/2013)',
      'EuVECA Regulation',
      'EuSEF Regulation',
      'ELTIF Regulation',
      'MMF Regulation',
    ],
  },
  {
    id: 'issuers',
    title: 'legislation_issuers',
    items: [
      'Transparency Law of 2007 (Law 190(I)/2007)',
      'Prospectus Law of 2019 (Law 114(I)/2019)',
      'Takeover Bids Law of 2007 (Law 41(I)/2007)',
      'Market Abuse Regulation (MAR)',
      'Short Selling Regulation',
      'European Green Bonds Regulation',
      'ESEF Regulation',
    ],
  },
  {
    id: 'financial-crimes',
    title: 'legislation_financial_crimes',
    items: [
      'Prevention and Suppression of Money Laundering and Terrorist Financing Law of 2024 (Law 22(I)/2024)',
      'FATF Recommendations',
      '4th and 5th EU AML Directives',
      'Sanctions/Restrictive Measures Framework',
    ],
  },
  {
    id: 'crypto',
    title: 'legislation_crypto',
    items: [
      'Markets in Crypto-Assets Regulation (MiCAR)',
      'DLT Pilot Regime Regulation',
      'Crypto-Assets Service Providers Framework',
    ],
  },
  {
    id: 'resilience',
    title: 'legislation_resilience',
    items: [
      'Digital Operational Resilience Act (DORA)',
      'NIS2 Directive',
      'Physical Resilience Framework',
    ],
  },
];

export default function LegislationPage() {
  const { t } = useTranslation('common');

  return (
    <div className="min-h-screen bg-background-50">
      {/* Header */}
      <section className="relative h-[280px] md:h-[360px] w-full overflow-hidden flex items-center">
        <div className="absolute inset-0">
          <img
            src="https://readdy.ai/api/search-image?query=European%20Parliament%20building%20interior%20with%20rows%20of%20seats%20and%20flags%2C%20classical%20legal%20architecture%2C%20warm%20golden%20lighting%2C%20marble%20columns%2C%20professional%20institutional%20photography%2C%20no%20people%2C%20dignified%20atmosphere&width=1600&height=900&seq=legislation-hero&orientation=landscape"
            alt="Legislation"
            className="w-full h-full object-cover"
          />
        </div>
        <div className="absolute inset-0 bg-background-950/70" />
        <div className="relative z-10 w-full px-4 md:px-8 lg:px-12">
          <div className="max-w-4xl">
            <h1 className="text-2xl md:text-4xl font-heading font-bold text-white leading-tight mb-3">
              {t('legislation_title')}
            </h1>
            <p className="text-base text-foreground-200 max-w-2xl leading-relaxed">
              {t('legislation_subtitle')}
            </p>
          </div>
        </div>
      </section>

      {/* Content */}
      <div className="w-full px-4 md:px-8 lg:px-12 py-10 md:py-16">
        <div className="max-w-5xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8">
            {legislationCategories.map((cat) => (
              <div
                key={cat.id}
                className="p-5 md:p-6 rounded-lg bg-background-100 border border-background-200/70"
              >
                <h2 className="text-lg font-heading font-semibold text-foreground-900 mb-4 flex items-center gap-2">
                  <div className="w-8 h-8 flex items-center justify-center rounded-md bg-primary-100 text-primary-700">
                    <i className="ri-file-text-line text-sm" />
                  </div>
                  {t(cat.title)}
                </h2>
                <ul className="space-y-2">
                  {cat.items.map((item, idx) => (
                    <li
                      key={idx}
                      className="flex items-start gap-2 text-sm text-foreground-700"
                    >
                      <i className="ri-arrow-right-s-line text-primary-600 mt-0.5 shrink-0" />
                      <span className="leading-relaxed">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          {/* ESMA Guidelines */}
          <div className="mt-8 md:mt-10 p-5 md:p-6 rounded-lg bg-accent-50 border border-accent-200/70">
            <h2 className="text-lg font-heading font-semibold text-accent-900 mb-3 flex items-center gap-2">
              <i className="ri-book-2-line text-accent-700" />
              {t('legislation_esma_title')}
            </h2>
            <p className="text-sm text-accent-700 leading-relaxed mb-4">
              {t('legislation_esma_text')}
            </p>
            <a
              href="https://www.esma.europa.eu/"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2 bg-accent-600 hover:bg-accent-700 text-white rounded-md text-sm font-medium transition-all"
            >
              {t('visit_esma')}
              <i className="ri-external-link-line" />
            </a>
          </div>

          {/* Full framework CTA */}
          <div className="mt-8 md:mt-10 text-center">
            <a
              href="https://www.cysec.gov.cy/en-GB/legislation/"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-6 py-3 bg-primary-600 hover:bg-primary-700 text-white rounded-md font-medium text-sm transition-all"
            >
              {t('view_full_framework')}
              <i className="ri-arrow-right-line" />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}