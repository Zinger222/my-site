import { useTranslation } from 'react-i18next';
import { warningsList } from '@/mocks/warnings';

export default function WarningsPage() {
  const { t } = useTranslation('common');

  return (
    <div className="min-h-screen bg-background-50">
      {/* Header */}
      <section className="relative h-[280px] md:h-[360px] w-full overflow-hidden flex items-center">
        <div className="absolute inset-0">
          <img
            src="https://readdy.ai/api/search-image?query=Red%20warning%20alert%20concept%20abstract%20background%2C%20dark%20red%20and%20orange%20gradient%20with%20digital%20security%20alert%20symbols%2C%20cybersecurity%20threat%20visualization%2C%20professional%20corporate%20illustration%20style%2C%20high%20contrast%20dramatic%20lighting%2C%20no%20text%20no%20people&width=1600&height=900&seq=warnings-hero&orientation=landscape"
            alt="Investor Warnings"
            className="w-full h-full object-cover"
          />
        </div>
        <div className="absolute inset-0 bg-background-950/70" />
        <div className="relative z-10 w-full px-4 md:px-8 lg:px-12">
          <div className="max-w-4xl">
            <h1 className="text-2xl md:text-4xl font-heading font-bold text-white leading-tight mb-3">
              {t('nav_warnings')}
            </h1>
            <p className="text-base text-foreground-200 max-w-2xl leading-relaxed">
              {t('warnings_hero_subtitle')}
            </p>
          </div>
        </div>
      </section>

      {/* Content */}
      <div className="w-full px-4 md:px-8 lg:px-12 py-10 md:py-16">
        <div className="max-w-5xl mx-auto">
          {/* Search */}
          <div className="mb-8 md:mb-10">
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1">
                <i className="ri-search-line absolute left-3 top-1/2 -translate-y-1/2 text-foreground-400" />
                <input
                  type="text"
                  placeholder={t('search_warnings')}
                  className="w-full pl-10 pr-4 py-3 rounded-md border border-background-300 bg-background-50 text-sm text-foreground-800 focus:outline-none focus:border-primary-400 focus:ring-1 focus:ring-primary-400"
                />
              </div>
              <button className="px-6 py-3 bg-primary-600 hover:bg-primary-700 text-white rounded-md text-sm font-medium transition-all whitespace-nowrap">
                {t('search')}
              </button>
            </div>
          </div>

          {/* IOSCO Link */}
          <div className="mb-8 p-4 md:p-5 rounded-lg bg-accent-50 border border-accent-200/70 flex flex-col md:flex-row md:items-center gap-4">
            <div className="w-10 h-10 rounded-full bg-accent-100 flex items-center justify-center text-accent-700 shrink-0">
              <i className="ri-global-line text-lg" />
            </div>
            <div className="flex-1">
              <h3 className="text-sm font-semibold text-accent-900 mb-1">
                {t('iosco_alerts_title')}
              </h3>
              <p className="text-xs text-accent-700">
                {t('iosco_alerts_text')}
              </p>
            </div>
            <a
              href="https://www.iosco.org/investor_protection/?subsection=investor_alerts_portal"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2 bg-accent-600 hover:bg-accent-700 text-white rounded-md text-sm font-medium transition-all whitespace-nowrap self-start"
            >
              {t('view_iosco')}
              <i className="ri-external-link-line" />
            </a>
          </div>

          {/* Warnings List */}
          <div className="space-y-3">
            {warningsList.map((warning) => (
              <div
                key={warning.id}
                className="flex flex-col md:flex-row md:items-center gap-3 p-4 md:p-5 rounded-lg bg-background-100 border-l-4 border-accent-600 hover:bg-background-200/70 transition-all"
              >
                <div className="flex items-center gap-3 md:w-48 shrink-0">
                  <div className="w-10 h-10 rounded-full bg-accent-100 flex items-center justify-center text-accent-700 shrink-0">
                    <i className="ri-error-warning-line text-lg" />
                  </div>
                  <div className="text-xs text-foreground-500">
                    {warning.date}
                  </div>
                </div>
                <div className="flex-1">
                  <div className="text-sm font-semibold text-foreground-900 mb-1">
                    {warning.entity}
                  </div>
                  <div className="text-xs text-foreground-500 flex flex-wrap items-center gap-2">
                    <span className="flex items-center gap-1">
                      <i className="ri-global-line" />
                      {warning.website}
                    </span>
                    <span className="hidden md:inline text-foreground-300">|</span>
                    <span className="text-accent-700 font-medium">{warning.reason}</span>
                  </div>
                </div>
                <a
                  href="https://www.cysec.gov.cy/en-GB/investor-protection/warnings/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="md:shrink-0 text-foreground-400 hover:text-primary-600 transition-colors"
                >
                  <i className="ri-arrow-right-line" />
                </a>
              </div>
            ))}
          </div>

          {/* Full list CTA */}
          <div className="mt-8 md:mt-10 text-center">
            <a
              href="https://www.cysec.gov.cy/en-GB/investor-protection/warnings/"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-6 py-3 bg-primary-600 hover:bg-primary-700 text-white rounded-md font-medium text-sm transition-all"
            >
              {t('view_all_warnings')}
              <i className="ri-arrow-right-line" />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}