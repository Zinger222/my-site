import { useState, useEffect, useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import { Link, useLocation } from 'react-router-dom';
import { setUserLanguage, type SupportedLang } from '@/i18n/detectLanguage';

const internalNavItems = [
  { key: 'nav_home', href: '/' },
  { key: 'nav_broker_check', href: '/broker-check' },
  { key: 'nav_about', href: '/about' },
  { key: 'nav_warnings', href: '/warnings' },
  { key: 'nav_legislation', href: '/legislation' },
  { key: 'nav_documents', href: '/documents' },
];

const externalNavItems = [
  { key: 'nav_news', href: 'https://www.cysec.gov.cy/en-GB/cysec/about-us/public-presence/' },
  { key: 'nav_registry', href: 'https://www.cysec.gov.cy/en-GB/entities/' },
  { key: 'nav_contact', href: 'https://www.cysec.gov.cy/en-GB/cysec/contact/' },
];

export default function Navbar() {
  const { t, i18n } = useTranslation('common');
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();

  const handleScroll = useCallback(() => {
    setScrolled(window.scrollY > 50);
  }, []);

  useEffect(() => {
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [handleScroll]);

  useEffect(() => {
    setMobileOpen(false);
  }, [location.pathname]);

  const [langOpen, setLangOpen] = useState(false);

  const currentLang = i18n.language?.startsWith('it')
    ? 'it'
    : i18n.language?.startsWith('en')
      ? 'en'
      : 'bg';

  const languages = [
    { code: 'bg', label: 'БГ', name: 'Български' },
    { code: 'en', label: 'EN', name: 'English' },
    { code: 'it', label: 'IT', name: 'Italiano' },
  ];

  const changeLang = (code: string) => {
    setUserLanguage(code as SupportedLang);
    setLangOpen(false);
  };

  const isHome = location.pathname === '/';

  const navBg = scrolled
    ? 'bg-background-50 shadow-md'
    : isHome
      ? 'bg-transparent'
      : 'bg-background-50 shadow-md';

  const textColor = scrolled || !isHome ? 'text-foreground-900' : 'text-white';
  const logoText = scrolled || !isHome ? 'text-primary-700' : 'text-white';
  const linkHover = scrolled || !isHome ? 'hover:text-primary-600' : 'hover:text-accent-400';

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${navBg}`}
    >
      <div className="w-full px-4 md:px-8 lg:px-12">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-lg flex items-center justify-center font-bold text-lg font-heading ${scrolled || !isHome ? 'bg-primary-700 text-white' : 'bg-white/20 text-white'}`}>
              C
            </div>
            <div className="hidden md:block">
              <div className={`font-heading text-sm font-bold leading-tight ${logoText}`}>
                CySEC
              </div>
              <div className={`text-[10px] leading-tight uppercase tracking-wider ${scrolled || !isHome ? 'text-foreground-600' : 'text-white/80'}`}>
                {currentLang === 'bg'
                  ? 'Комисия за ценни книжа и борси'
                  : currentLang === 'it'
                    ? 'Cyprus Securities & Exchange Commission'
                    : 'Cyprus Securities & Exchange Commission'}
              </div>
            </div>
          </Link>

          {/* Desktop Nav Links */}
          <div className="hidden lg:flex items-center gap-6">
            {internalNavItems.map((item) => (
              <Link
                key={item.key}
                to={item.href}
                className={`text-sm font-medium transition-colors whitespace-nowrap ${textColor} ${linkHover}`}
              >
                {t(item.key)}
              </Link>
            ))}
            {externalNavItems.map((item) => (
              <a
                key={item.key}
                href={item.href}
                target="_blank"
                rel="noopener noreferrer"
                className={`text-sm font-medium transition-colors whitespace-nowrap ${textColor} ${linkHover}`}
              >
                {t(item.key)}
              </a>
            ))}
          </div>

          {/* Right side: Language + Mobile menu */}
          <div className="flex items-center gap-3">
            {/* Complaint button on desktop */}
            <Link
              to="/complaint"
              className={`hidden md:flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-all whitespace-nowrap ${scrolled || !isHome ? 'bg-primary-600 text-white hover:bg-primary-700' : 'bg-white/20 text-white hover:bg-white/30'}`}
            >
              <i className="ri-file-list-3-line" />
              {t('nav_complaint')}
            </Link>

            {/* Language switcher */}
            <div className="relative">
              <button
                onClick={() => setLangOpen((prev) => !prev)}
                className={`flex items-center gap-1 px-3 py-1.5 rounded-md text-sm font-semibold transition-all cursor-pointer ${scrolled || !isHome ? 'bg-background-200 text-foreground-700 hover:bg-background-300' : 'bg-white/20 text-white hover:bg-white/30'}`}
              >
                <i className="ri-global-line" />
                <span>{languages.find((l) => l.code === currentLang)?.label}</span>
                <i className={`ri-arrow-down-s-line text-base transition-transform ${langOpen ? 'rotate-180' : ''}`} />
              </button>
              {langOpen && (
                <>
                  <div className="fixed inset-0 z-40" onClick={() => setLangOpen(false)} />
                  <div className="absolute right-0 top-full mt-2 w-40 rounded-lg bg-background-50 border border-background-200 shadow-lg overflow-hidden z-50 py-1">
                    {languages.map((lang) => (
                      <button
                        key={lang.code}
                        onClick={() => changeLang(lang.code)}
                        className={`w-full flex items-center justify-between px-4 py-2 text-sm transition-colors cursor-pointer ${currentLang === lang.code ? 'bg-primary-50 text-primary-700 font-semibold' : 'text-foreground-800 hover:bg-background-100'}`}
                      >
                        <span>{lang.name}</span>
                        {currentLang === lang.code && <i className="ri-check-line text-primary-600" />}
                      </button>
                    ))}
                  </div>
                </>
              )}
            </div>

            {/* Mobile hamburger */}
            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className={`lg:hidden p-2 rounded-md transition-colors ${scrolled || !isHome ? 'text-foreground-900 hover:bg-background-200' : 'text-white hover:bg-white/20'}`}
            >
              <i className={`ri-${mobileOpen ? 'close' : 'menu'}-line text-xl`} />
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div className="lg:hidden bg-background-50 border-t border-background-200 shadow-lg">
          <div className="px-4 py-4 space-y-1">
            {internalNavItems.map((item) => (
              <Link
                key={item.key}
                to={item.href}
                className="block px-4 py-3 rounded-md text-sm font-medium text-foreground-800 hover:bg-background-100 hover:text-primary-700 transition-colors"
              >
                {t(item.key)}
              </Link>
            ))}
            {externalNavItems.map((item) => (
              <a
                key={item.key}
                href={item.href}
                target="_blank"
                rel="noopener noreferrer"
                className="block px-4 py-3 rounded-md text-sm font-medium text-foreground-800 hover:bg-background-100 hover:text-primary-700 transition-colors"
              >
                {t(item.key)}
              </a>
            ))}
            <Link
              to="/complaint"
              className="block px-4 py-3 rounded-md text-sm font-medium bg-primary-600 text-white hover:bg-primary-700 transition-colors"
            >
              {t('nav_complaint')}
            </Link>
          </div>
        </div>
      )}
    </nav>
  );
}