import { useTranslation } from 'react-i18next';
import { Link } from 'react-router-dom';

const footerLinkColumns = [
  {
    title: 'Public Information',
    titleKey: 'footer_nav_public',
    items: [
      { label: 'About CySEC', href: '/about', external: false },
      { label: 'News', href: 'https://www.cysec.gov.cy/en-GB/cysec/about-us/public-presence/', external: true },
      { label: 'Careers', href: 'https://www.cysec.gov.cy/en-GB/cysec/about-us/recruitment/', external: true },
      { label: 'Press Releases', href: 'https://www.cysec.gov.cy/en-GB/cysec/about-us/public-presence/', external: true },
    ],
  },
  {
    title: 'Regulated Entities',
    titleKey: 'footer_nav_regulated',
    items: [
      { label: 'Licensed Entities', href: 'https://www.cysec.gov.cy/en-GB/entities/', external: true },
      { label: 'CIF Authorisation', href: 'https://www.cysec.gov.cy/en-GB/entities/investment-firms/', external: true },
      { label: 'Certifications', href: 'https://www.cysec.gov.cy/en-GB/public-info/certifications-and-seminars/', external: true },
      { label: 'Annual Fees', href: 'https://www.cysec.gov.cy/en-GB/entities/fees/', external: true },
    ],
  },
  {
    title: 'Regulatory Framework',
    titleKey: 'footer_nav_framework',
    items: [
      { label: 'Legislation', href: '/legislation', external: false },
      { label: 'Documents', href: '/documents', external: false },
      { label: 'Circulars', href: 'https://www.cysec.gov.cy/en-GB/public-info/circulars/', external: true },
      { label: 'Guidelines', href: 'https://www.esma.europa.eu/', external: true },
    ],
  },
  {
    title: 'Investor Protection',
    titleKey: 'footer_nav_protection',
    items: [
      { label: 'Investor Warnings', href: '/warnings', external: false },
      { label: 'Submit Complaint', href: '/complaint', external: false },
      { label: 'Compensation Fund', href: 'https://www.cysec.gov.cy/en-GB/investor-protection/tae/', external: true },
      { label: 'Education Hub', href: 'https://www.cysec.gov.cy/en-GB/investor-protection/financial-education/', external: true },
    ],
  },
  {
    title: 'Registries & Portals',
    titleKey: 'footer_nav_registries',
    items: [
      { label: 'Company Registry', href: 'https://www.cysec.gov.cy/en-GB/entities/', external: true },
      { label: 'Approved Domains', href: 'https://www.cysec.gov.cy/entities/investment-firms/approved-domains/', external: true },
      { label: 'Sanctions Register', href: 'https://www.cysec.gov.cy/en-GB/public-info/administrative-sanctions/', external: true },
      { label: 'Public Consultations', href: 'https://www.cysec.gov.cy/en-GB/public-info/consultation-papers/', external: true },
    ],
  },
];

export default function Footer() {
  const { t } = useTranslation('common');

  return (
    <footer className="bg-background-950 text-foreground-100">
      {/* Main footer content */}
      <div className="w-full px-4 md:px-8 lg:px-12 py-12 md:py-16">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8 lg:gap-6">
          {/* Contact info */}
          <div className="lg:col-span-1">
            <h4 className="font-heading text-lg font-semibold text-white mb-4">
              {t('footer_information')}
            </h4>
            <div className="space-y-3 text-sm text-foreground-300">
              <div className="flex items-start gap-2">
                <i className="ri-map-pin-line mt-0.5 text-accent-500" />
                <span>{t('footer_address')}</span>
              </div>
              <div className="flex items-center gap-2">
                <i className="ri-archive-line text-accent-500" />
                <span>{t('footer_post')}</span>
              </div>
            </div>

            {/* Social icons */}
            <div className="flex items-center gap-3 mt-6">
              <a href="https://www.linkedin.com/company/cyprus-securities-and-exchange-commission/" target="_blank" rel="noopener noreferrer" className="w-9 h-9 rounded-full bg-foreground-800/30 flex items-center justify-center text-foreground-300 hover:bg-accent-600 hover:text-white transition-all">
                <i className="ri-linkedin-fill" />
              </a>
              <a href="https://twitter.com/CySEC_official" target="_blank" rel="noopener noreferrer" className="w-9 h-9 rounded-full bg-foreground-800/30 flex items-center justify-center text-foreground-300 hover:bg-accent-600 hover:text-white transition-all">
                <i className="ri-twitter-x-line" />
              </a>
              <a href="https://www.youtube.com/@CySEC_Cyprus" target="_blank" rel="noopener noreferrer" className="w-9 h-9 rounded-full bg-foreground-800/30 flex items-center justify-center text-foreground-300 hover:bg-accent-600 hover:text-white transition-all">
                <i className="ri-youtube-fill" />
              </a>
            </div>
          </div>

          {/* Footer link columns */}
          {footerLinkColumns.map((column) => (
            <div key={column.title}>
              <h4 className="font-heading text-sm font-semibold text-white mb-4 uppercase tracking-wider">
                {t(column.titleKey as never)}
              </h4>
              <ul className="space-y-2">
                {column.items.map((item) => (
                  <li key={item.label}>
                    {item.external ? (
                      <a
                        href={item.href}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-sm text-foreground-400 hover:text-accent-400 transition-colors"
                      >
                        {item.label}
                      </a>
                    ) : (
                      <Link
                        to={item.href}
                        className="text-sm text-foreground-400 hover:text-accent-400 transition-colors"
                      >
                        {item.label}
                      </Link>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-foreground-800/30">
        <div className="w-full px-4 md:px-8 lg:px-12 py-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-xs text-foreground-500">
              {t('footer_copyright')}
            </p>
            <div className="flex items-center gap-4 text-xs text-foreground-500">
              <a href="https://www.cysec.gov.cy/en-GB/cysec/privacy-notice/" target="_blank" rel="noopener noreferrer" className="hover:text-foreground-300 transition-colors">Privacy Policy</a>
              <a href="https://www.cysec.gov.cy/en-GB/cysec/privacy-notice/" target="_blank" rel="noopener noreferrer" className="hover:text-foreground-300 transition-colors">Cookie Policy</a>
              <a href="https://www.cysec.gov.cy/en-GB/cysec/contact/" target="_blank" rel="noopener noreferrer" className="hover:text-foreground-300 transition-colors">Accessibility</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}