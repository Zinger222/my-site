export const documentCategories = [
  {
    id: 'forms',
    icon: 'ri-file-list-3-line',
    titleKey: 'docs_forms_title',
    descKey: 'docs_forms_desc',
    items: [
      { nameKey: 'docs_form_2', file: 'Жалба-до-КЦКБ.docx', size: 'DOCX · 96 KB', url: 'https://www.cysec.gov.cy/en-GB/investor-protection/how-to-complain/' },
      { nameKey: 'docs_form_3', file: 'Сигнал-за-измама.pdf', size: 'PDF · 212 KB', url: 'https://www.cybercrime.bg/investment-fraud.html' },
      { nameKey: 'docs_form_4', file: 'Формуляр-за-финансов-омбудсман.pdf', size: 'PDF · 158 KB', url: 'https://www.cysec.gov.cy/en-GB/investor-protection/fin-ombud/' },
    ],
  },
  {
    id: 'laws',
    icon: 'ri-scales-3-line',
    titleKey: 'docs_laws_title',
    descKey: 'docs_laws_desc',
    items: [
      { nameKey: 'docs_law_1', file: 'Закон-87(I)-2017.pdf', size: 'PDF · 1.2 MB', url: 'https://www.cysec.gov.cy/en-GB/legislation/' },
      { nameKey: 'docs_law_2', file: 'Наредба-за-MiFIR.pdf', size: 'PDF · 980 KB', url: 'https://www.cysec.gov.cy/en-GB/legislation/' },
      { nameKey: 'docs_law_3', file: 'Закон-за-АМЛ-2024.pdf', size: 'PDF · 1.5 MB', url: 'https://www.cysec.gov.cy/en-GB/legislation/' },
      { nameKey: 'docs_law_4', file: 'Регламент-DORA.pdf', size: 'PDF · 1.1 MB', url: 'https://www.cysec.gov.cy/en-GB/legislation/resilience/' },
      { nameKey: 'docs_law_5', file: 'Регламент-MiCAR.pdf', size: 'PDF · 1.3 MB', url: 'https://www.cysec.gov.cy/en-GB/legislation/services-markets/Markets-in-crypto-assets/' },
    ],
  },
  {
    id: 'guides',
    icon: 'ri-book-open-line',
    titleKey: 'docs_guides_title',
    descKey: 'docs_guides_desc',
    items: [
      { nameKey: 'docs_guide_1', file: 'Памятка-за-инвестора.pdf', size: 'PDF · 320 KB', url: 'https://www.cysec.gov.cy/en-GB/investor-protection/financial-education/' },
      { nameKey: 'docs_guide_2', file: 'Как-да-разпознаем-измама.pdf', size: 'PDF · 410 KB', url: 'https://www.cysec.gov.cy/en-GB/investor-protection/warnings/' },
      { nameKey: 'docs_guide_3', file: '7-въпроса-преди-инвестиция.pdf', size: 'PDF · 280 KB', url: 'https://www.cysec.gov.cy/en-GB/investor-protection/financial-education/' },
      { nameKey: 'docs_guide_4', file: 'Ръководство-за-киберсигурност.pdf', size: 'PDF · 540 KB', url: 'https://www.cybercrime.bg/' },
      { nameKey: 'docs_guide_5', file: 'Наръчник-за-финансова-устойчивост.pdf', size: 'PDF · 390 KB', url: 'https://www.cysec.gov.cy/en-GB/legislation/resilience/' },
    ],
  },
];