export const warningsList = [
  {
    id: '1',
    date: '25 Aug. 2026',
    entity: 'FXGlobalTrade Ltd',
    website: 'fxglobaltrade.com',
    reason: 'Unauthorised investment services provider',
  },
  {
    id: '2',
    date: '22 Aug. 2026',
    entity: 'CryptoWealth Partners',
    website: 'cryptowealth-partners.net',
    reason: 'Operating without CIF authorisation',
  },
  {
    id: '3',
    date: '18 Aug. 2026',
    entity: 'PrimeCapital Markets',
    website: 'primecapitalmarkets.com',
    reason: 'Offering investment services without authorisation',
  },
  {
    id: '4',
    date: '15 Aug. 2026',
    entity: 'EuroInvest FX',
    website: 'euroinvestfx.com',
    reason: 'Clone firm impersonating authorised entity',
  },
  {
    id: '5',
    date: '10 Aug. 2026',
    entity: 'Global Asset Management Ltd',
    website: 'globalassetmanagement.eu',
    reason: 'Fraudulent investment scheme',
  },
];