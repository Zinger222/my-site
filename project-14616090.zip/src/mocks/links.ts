export const usefulLinks = [
  {
    id: '1',
    title: 'ESMA',
    url: 'https://www.esma.europa.eu/',
    image: 'https://readdy.ai/api/search-image?query=Modern%20European%20financial%20regulator%20abstract%20digital%20background%20with%20EU%20flag%20elements%2C%20clean%20minimalist%20design%2C%20dark%20blue%20and%20green%20gradient%20with%20geometric%20shapes%2C%20professional%20corporate%20style%2C%20high%20detail&width=400&height=250&seq=useful-esma&orientation=landscape',
  },
  {
    id: '2',
    title: 'European Commission',
    url: 'https://ec.europa.eu/',
    image: 'https://readdy.ai/api/search-image?query=European%20Union%20institutional%20building%20facade%20with%20EU%20flag%2C%20Brussels%20architecture%2C%20modern%20governmental%20office%20exterior%2C%20clean%20professional%20photography%20style%2C%20bright%20daylight%2C%20symmetrical%20composition&width=400&height=250&seq=useful-ec&orientation=landscape',
  },
  {
    id: '3',
    title: 'Whistleblowing',
    url: 'https://www.cysec.gov.cy/en-GB/investor-protection/whistleblowing/',
    image: 'https://readdy.ai/api/search-image?query=Anonymous%20reporting%20concept%2C%20silhouette%20of%20person%20speaking%20at%20microphone%20with%20encrypted%20data%20visualization%20around%2C%20dark%20atmospheric%20lighting%2C%20cybersecurity%20theme%2C%20abstract%20digital%20protection%20shield%2C%20professional%20illustration%20style&width=400&height=250&seq=useful-whistle&orientation=landscape',
  },
  {
    id: '4',
    title: 'Administrative Sanctions',
    url: 'https://www.cysec.gov.cy/en-GB/public-info/administrative-sanctions/',
    image: 'https://readdy.ai/api/search-image?query=Gavel%20and%20legal%20documents%20on%20dark%20wooden%20desk%2C%20courtroom%20justice%20symbol%2C%20professional%20legal%20photography%20with%20dramatic%20lighting%2C%20shallow%20depth%20of%20field%2C%20administrative%20law%20and%20regulation%20concept&width=400&height=250&seq=useful-sanctions&orientation=landscape',
  },
  {
    id: '5',
    title: 'Digital Signature',
    url: 'https://www.cysec.gov.cy/en-GB/public-info/digital-signature/',
    image: 'https://readdy.ai/api/search-image?query=Digital%20signature%20and%20electronic%20document%20security%20concept%2C%20fingerprint%20scan%20on%20digital%20interface%2C%20holographic%20verification%20badge%2C%20futuristic%20fintech%20technology%2C%20clean%20minimalist%20dark%20background%2C%20glowing%20cyan%20accent%20lines&width=400&height=250&seq=useful-digital&orientation=landscape',
  },
  {
    id: '6',
    title: 'Digital Finance & Innovation',
    url: 'https://www.cysec.gov.cy/en-GB/legislation/services-markets/Markets-in-crypto-assets/',
    image: 'https://readdy.ai/api/search-image?query=Digital%20finance%20innovation%20hub%20concept%2C%20abstract%20blockchain%20network%20nodes%20connected%20in%20geometric%20pattern%2C%20fintech%20data%20streams%2C%20dark%20background%20with%20green%20and%20gold%20neon%20glow%2C%20modern%20corporate%20illustration%20style%2C%20high%20detail&width=400&height=250&seq=useful-innovation&orientation=landscape',
  },
];